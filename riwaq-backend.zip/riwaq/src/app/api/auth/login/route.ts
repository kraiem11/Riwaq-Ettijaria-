// ╔═══════════════════════════════════════╗
// ║  POST /api/auth/login                 ║
// ╚═══════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { verifyPassword, generateTokens, createSession, setAuthCookies } from "@/lib/auth";
import { parseBody, ok, err, serverError } from "@/lib/api";
import { LoginSchema } from "@/lib/validations";

export async function POST(req: NextRequest) {
  const { data, error } = await parseBody(req, LoginSchema);
  if (error) return error;

  try {
    const user = await prisma.user.findUnique({
      where:  { email: data.email },
      select: { id: true, email: true, passwordHash: true, role: true, kycLevel: true, status: true, displayName: true, avatarUrl: true },
    });

    // Constant-time check to prevent user enumeration
    const passwordOk = user
      ? await verifyPassword(data.password, user.passwordHash)
      : await verifyPassword(data.password, "$2a$12$placeholder_hash_to_prevent_timing");

    if (!user || !passwordOk) {
      return err("البريد الإلكتروني أو كلمة المرور غير صحيحة", 401);
    }

    if (user.status === "BANNED")     return err("هذا الحساب محظور. تواصل مع الدعم.", 403);
    if (user.status === "SUSPENDED")  return err("هذا الحساب موقوف مؤقتاً.", 403);

    // Update last active
    await prisma.user.update({
      where: { id: user.id },
      data:  { lastActiveAt: new Date() },
    });

    const ip        = req.headers.get("x-forwarded-for") ?? req.ip ?? "unknown";
    const ua        = req.headers.get("user-agent") ?? "";
    const sessionId = await createSession(user.id, ip, ua);
    const tokens    = await generateTokens({
      sub:       user.id,
      email:     user.email,
      role:      user.role as any,
      kycLevel:  user.kycLevel as any,
      sessionId,
    });

    setAuthCookies(tokens);

    return ok({
      user: {
        id:          user.id,
        email:       user.email,
        displayName: user.displayName,
        avatarUrl:   user.avatarUrl,
        role:        user.role,
        kycLevel:    user.kycLevel,
        status:      user.status,
      },
      tokens,
    });

  } catch (e) {
    return serverError(e);
  }
}
