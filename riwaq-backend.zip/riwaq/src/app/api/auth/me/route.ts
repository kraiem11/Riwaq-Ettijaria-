// ╔═══════════════════════════════════════╗
// ║  GET /api/auth/me                     ║
// ║  DELETE /api/auth/me  (logout)        ║
// ╚═══════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, clearAuthCookies } from "@/lib/auth";
import { ok, unauthorized, notFound, serverError, filsToAmount } from "@/lib/api";

export async function GET(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return unauthorized();

  try {
    const user = await prisma.user.findUnique({
      where:  { id: auth.sub },
      select: {
        id: true, username: true, displayName: true, email: true, phone: true,
        avatarUrl: true, coverUrl: true, bio: true, tagline: true,
        role: true, status: true, kycLevel: true,
        country: true, city: true, timezone: true, language: true,
        hourlyRate: true, availability: true, responseTime: true,
        avgRating: true, reviewCount: true, completedJobs: true,
        successRate: true, totalEarnings: true, totalSpent: true, level: true,
        emailNotifs: true, pushNotifs: true,
        createdAt: true, lastActiveAt: true,
        skills:    { select: { skill: true, level: true, yearsExp: true, endorsed: true }, orderBy: { sortOrder: "asc" } },
        languages: { select: { language: true, proficiency: true } },
        wallet:    { select: { balanceFils: true, escrowFils: true, pendingFils: true, currency: true } },
      },
    });

    if (!user) return notFound("المستخدم");

    const formatted = {
      ...user,
      hourlyRate:    user.hourlyRate    ? parseFloat(user.hourlyRate.toString())    : null,
      avgRating:     parseFloat(user.avgRating.toString()),
      successRate:   parseFloat(user.successRate.toString()),
      totalEarnings: filsToAmount(user.totalEarnings),
      totalSpent:    filsToAmount(user.totalSpent),
      wallet: user.wallet ? {
        balance:  filsToAmount(user.wallet.balanceFils),
        escrow:   filsToAmount(user.wallet.escrowFils),
        pending:  filsToAmount(user.wallet.pendingFils),
        currency: user.wallet.currency,
      } : null,
    };

    return ok(formatted);
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return unauthorized();

  clearAuthCookies();

  // Optionally invalidate the server-side session
  try {
    await prisma.userSession.deleteMany({
      where: { userId: auth.sub },
    });
  } catch { /* silent */ }

  return ok({ message: "تم تسجيل الخروج بنجاح" });
}
