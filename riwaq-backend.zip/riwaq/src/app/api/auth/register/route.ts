// ╔═══════════════════════════════════════╗
// ║  POST /api/auth/register              ║
// ╚═══════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { hashPassword, generateTokens, createSession, setAuthCookies, createNotification } from "@/lib/auth";
import { parseBody, created, err, serverError } from "@/lib/api";
import { RegisterSchema } from "@/lib/validations";

export async function POST(req: NextRequest) {
  const { data, error } = await parseBody(req, RegisterSchema);
  if (error) return error;

  // Check uniqueness
  const [existingEmail, existingUsername] = await Promise.all([
    prisma.user.findUnique({ where: { email: data.email }, select: { id: true } }),
    prisma.user.findUnique({ where: { username: data.username }, select: { id: true } }),
  ]);

  if (existingEmail)    return err("هذا البريد الإلكتروني مسجّل بالفعل", 409);
  if (existingUsername) return err("اسم المستخدم محجوز بالفعل", 409);

  try {
    const passwordHash = await hashPassword(data.password);

    const user = await prisma.$transaction(async (tx) => {
      // Create user
      const newUser = await tx.user.create({
        data: {
          email:       data.email,
          passwordHash,
          username:    data.username,
          displayName: data.displayName,
          role:        data.role as any,
          phone:       data.phone,
          country:     data.country,
        },
        select: { id: true, email: true, role: true, kycLevel: true },
      });

      // Create wallet
      await tx.wallet.create({ data: { userId: newUser.id } });

      return newUser;
    });

    // Create session & tokens
    const ip        = req.headers.get("x-forwarded-for") ?? req.ip ?? "unknown";
    const ua        = req.headers.get("user-agent") ?? "";
    const sessionId = await createSession(user.id, ip, ua);
    const tokens    = await generateTokens({ sub: user.id, email: user.email, role: user.role as any, kycLevel: user.kycLevel as any, sessionId });

    setAuthCookies(tokens);

    // Welcome notification (async — don't await)
    createNotification({
      userId:    user.id,
      type:      "SYSTEM_ALERT",
      title:     "مرحباً بك في رواق! 🎉",
      body:      "حسابك جاهز. أكمل ملفك الشخصي لتحسين فرص الحصول على عقود.",
      actionUrl: "/dashboard/profile",
    }).catch(console.error);

    return created({
      user:   { id: user.id, email: user.email, role: user.role },
      tokens,
    });

  } catch (e) {
    return serverError(e);
  }
}
