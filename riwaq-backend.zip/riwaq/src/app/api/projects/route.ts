// ╔═══════════════════════════════════════════════╗
// ║  GET  /api/projects   — Browse / Search       ║
// ║  POST /api/projects   — Create project        ║
// ╚═══════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, canActAsClient } from "@/lib/auth";
import { ok, created, err, forbidden, serverError, parseBody, parseQuery, buildPagination, paginationSkip } from "@/lib/api";
import { CreateProjectSchema, ProjectFiltersSchema } from "@/lib/validations";

// ── GET — public browse with filters ────────────────────────
export async function GET(req: NextRequest) {
  const { data: filters, error } = parseQuery(req, ProjectFiltersSchema);
  if (error) return error;

  try {
    const where: any = {
      status:    "OPEN",
      deletedAt: null,
    };

    if (filters.category)        where.category        = filters.category;
    if (filters.experienceLevel) where.experienceLevel = filters.experienceLevel;
    if (filters.timeline)        where.timeline        = filters.timeline;

    if (filters.budgetMin || filters.budgetMax) {
      where.budgetMax = {};
      if (filters.budgetMin) where.budgetMax.gte = filters.budgetMin;
      if (filters.budgetMax) where.budgetMax.lte = filters.budgetMax;
    }

    // Arabic full-text search via pg_trgm (trigram similarity)
    if (filters.search) {
      where.OR = [
        { title:       { contains: filters.search, mode: "insensitive" } },
        { description: { contains: filters.search, mode: "insensitive" } },
        { skills:      { has: filters.search } },
      ];
    }

    const [projects, total] = await Promise.all([
      prisma.project.findMany({
        where,
        skip:    paginationSkip(filters.page, filters.limit),
        take:    filters.limit,
        orderBy: { [filters.sortBy]: filters.order },
        select: {
          id: true, title: true, description: true, category: true, skills: true,
          budgetType: true, budgetMin: true, budgetMax: true, currency: true,
          timeline: true, experienceLevel: true, status: true,
          proposalCount: true, viewCount: true, aiGenerated: true,
          publishedAt: true, deadline: true, createdAt: true,
          client: {
            select: {
              id: true, username: true, displayName: true, avatarUrl: true,
              country: true, avgRating: true, reviewCount: true, completedJobs: true,
            },
          },
        },
      }),
      prisma.project.count({ where }),
    ]);

    // Increment view counts in background (fire and forget)
    if (projects.length > 0) {
      const ids = projects.map(p => p.id);
      prisma.project.updateMany({
        where: { id: { in: ids } },
        data:  { viewCount: { increment: 1 } },
      }).catch(console.error);
    }

    const formatted = projects.map(p => ({
      ...p,
      budgetMin: parseFloat(p.budgetMin.toString()),
      budgetMax: parseFloat(p.budgetMax.toString()),
    }));

    return ok(formatted, buildPagination(filters.page, filters.limit, total));
  } catch (e) {
    return serverError(e);
  }
}

// ── POST — create project (clients only) ────────────────────
export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);
  if (!canActAsClient(auth.role)) return forbidden("يمكن للعملاء فقط نشر المشاريع");

  const { data, error } = await parseBody(req, CreateProjectSchema);
  if (error) return error;

  try {
    const project = await prisma.project.create({
      data: {
        clientId:        auth.sub,
        title:           data.title,
        description:     data.description,
        category:        data.category as any,
        skills:          data.skills,
        budgetType:      data.budgetType,
        budgetMin:       data.budgetMin,
        budgetMax:       data.budgetMax,
        timeline:        data.timeline,
        experienceLevel: (data.experienceLevel ?? "MID") as any,
        aiGenerated:     data.aiGenerated ?? false,
        aiPrompt:        data.aiPrompt,
        status:          "OPEN",
        publishedAt:     new Date(),
        deadline:        data.deadline ? new Date(data.deadline) : null,
      },
      include: {
        client: { select: { id: true, username: true, displayName: true, avatarUrl: true, country: true } },
      },
    });

    const formatted = {
      ...project,
      budgetMin: parseFloat(project.budgetMin.toString()),
      budgetMax: parseFloat(project.budgetMax.toString()),
    };

    return created(formatted);
  } catch (e) {
    return serverError(e);
  }
}
