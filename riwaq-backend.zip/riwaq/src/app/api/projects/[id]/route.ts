// ╔══════════════════════════════════════════════════╗
// ║  GET    /api/projects/:id                        ║
// ║  PATCH  /api/projects/:id                        ║
// ║  DELETE /api/projects/:id                        ║
// ╚══════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest } from "@/lib/auth";
import { ok, err, notFound, forbidden, serverError, parseBody } from "@/lib/api";
import { z } from "zod";

const UpdateProjectSchema = z.object({
  title:           z.string().min(10).max(300).optional(),
  description:     z.string().min(50).max(10000).optional(),
  skills:          z.array(z.string()).min(1).max(15).optional(),
  budgetMin:       z.number().positive().optional(),
  budgetMax:       z.number().positive().optional(),
  timeline:        z.enum(["1w","2w","1m","3m+"]).optional(),
  experienceLevel: z.enum(["ENTRY","MID","EXPERT"]).optional(),
  status:          z.enum(["OPEN","CANCELLED"]).optional(),
});

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const project = await prisma.project.findUnique({
      where: { id: params.id, deletedAt: null },
      include: {
        client: {
          select: {
            id: true, username: true, displayName: true, avatarUrl: true,
            country: true, avgRating: true, reviewCount: true, completedJobs: true,
            createdAt: true,
          },
        },
        _count: { select: { proposals: true } },
      },
    });

    if (!project) return notFound("المشروع");

    return ok({
      ...project,
      budgetMin: parseFloat(project.budgetMin.toString()),
      budgetMax: parseFloat(project.budgetMax.toString()),
    });
  } catch (e) {
    return serverError(e);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, UpdateProjectSchema);
  if (error) return error;

  try {
    const project = await prisma.project.findUnique({
      where:  { id: params.id, deletedAt: null },
      select: { id: true, clientId: true, status: true },
    });

    if (!project) return notFound("المشروع");
    if (project.clientId !== auth.sub && auth.role !== "ADMIN") return forbidden();
    if (project.status === "COMPLETED" || project.status === "IN_PROGRESS") {
      return err("لا يمكن تعديل مشروع قيد التنفيذ أو مكتمل");
    }

    const updated = await prisma.project.update({
      where: { id: params.id },
      data:  {
        ...(data.title           && { title: data.title }),
        ...(data.description     && { description: data.description }),
        ...(data.skills          && { skills: data.skills }),
        ...(data.budgetMin       && { budgetMin: data.budgetMin }),
        ...(data.budgetMax       && { budgetMax: data.budgetMax }),
        ...(data.timeline        && { timeline: data.timeline }),
        ...(data.experienceLevel && { experienceLevel: data.experienceLevel as any }),
        ...(data.status          && { status: data.status as any }),
      },
    });

    return ok({ ...updated, budgetMin: parseFloat(updated.budgetMin.toString()), budgetMax: parseFloat(updated.budgetMax.toString()) });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  try {
    const project = await prisma.project.findUnique({
      where:  { id: params.id, deletedAt: null },
      select: { id: true, clientId: true, status: true },
    });

    if (!project) return notFound("المشروع");
    if (project.clientId !== auth.sub && auth.role !== "ADMIN") return forbidden();
    if (project.status === "IN_PROGRESS") return err("لا يمكن حذف مشروع قيد التنفيذ");

    // Soft delete
    await prisma.project.update({
      where: { id: params.id },
      data:  { deletedAt: new Date(), status: "CANCELLED" },
    });

    return ok({ message: "تم حذف المشروع بنجاح" });
  } catch (e) {
    return serverError(e);
  }
}
