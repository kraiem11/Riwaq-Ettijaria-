// ╔═════════════════════════════════════════════════════════╗
// ║  GET  /api/projects/:id/proposals  — client sees all   ║
// ║  POST /api/projects/:id/proposals  — freelancer bids   ║
// ╚═════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, canActAsFreelancer, createNotification } from "@/lib/auth";
import { ok, created, err, forbidden, notFound, serverError, parseBody } from "@/lib/api";
import { CreateProposalSchema } from "@/lib/validations";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  try {
    const project = await prisma.project.findUnique({
      where:  { id: params.id, deletedAt: null },
      select: { clientId: true },
    });
    if (!project) return notFound("المشروع");
    if (project.clientId !== auth.sub && auth.role !== "ADMIN") return forbidden();

    const proposals = await prisma.proposal.findMany({
      where:   { projectId: params.id },
      orderBy: [{ aiMatchScore: "desc" }, { createdAt: "asc" }],
      include: {
        freelancer: {
          select: {
            id: true, username: true, displayName: true, avatarUrl: true,
            country: true, avgRating: true, reviewCount: true, completedJobs: true,
            hourlyRate: true, level: true,
            skills: { select: { skill: true, level: true }, take: 5 },
          },
        },
      },
    });

    // Mark as viewed
    await prisma.proposal.updateMany({
      where: { projectId: params.id, viewedByClient: false },
      data:  { viewedByClient: true, viewedAt: new Date() },
    });

    const formatted = proposals.map(p => ({
      ...p,
      bidAmount: parseFloat(p.bidAmount.toString()),
      freelancer: {
        ...p.freelancer,
        hourlyRate: p.freelancer.hourlyRate ? parseFloat(p.freelancer.hourlyRate.toString()) : null,
        avgRating:  parseFloat(p.freelancer.avgRating.toString()),
      },
    }));

    return ok(formatted);
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);
  if (!canActAsFreelancer(auth.role)) return forbidden("يمكن للمستقلين فقط تقديم العروض");

  const { data, error } = await parseBody(req, CreateProposalSchema);
  if (error) return error;

  try {
    const project = await prisma.project.findUnique({
      where:  { id: params.id, deletedAt: null, status: "OPEN" },
      select: { id: true, clientId: true, skills: true, budgetMin: true, budgetMax: true },
    });

    if (!project)                      return notFound("المشروع");
    if (project.clientId === auth.sub) return err("لا يمكنك تقديم عرض على مشروعك الخاص");

    // Check duplicate
    const existing = await prisma.proposal.findUnique({
      where: { projectId_freelancerId: { projectId: params.id, freelancerId: auth.sub } },
    });
    if (existing) return err("لقد قدّمت عرضاً على هذا المشروع مسبقاً", 409);

    // Calculate AI match score (simple heuristic here; replace with real ML)
    const freelancerSkills = await prisma.userSkill.findMany({
      where:  { userId: auth.sub },
      select: { skill: true },
    });
    const fSkillNames = new Set(freelancerSkills.map(s => s.skill.toLowerCase()));
    const matchCount  = project.skills.filter(s => fSkillNames.has(s.toLowerCase())).length;
    const aiMatchScore = project.skills.length > 0
      ? parseFloat(((matchCount / project.skills.length) * 100).toFixed(1))
      : 50;

    const proposal = await prisma.$transaction(async (tx) => {
      const p = await tx.proposal.create({
        data: {
          projectId:    params.id,
          freelancerId: auth.sub,
          coverLetter:  data.coverLetter,
          bidAmount:    data.bidAmount,
          bidType:      data.bidType,
          deliveryDays: data.deliveryDays,
          milestones:   data.milestones ?? undefined,
          attachments:  data.attachments ?? [],
          aiMatchScore,
        },
      });
      // Increment counter
      await tx.project.update({
        where: { id: params.id },
        data:  { proposalCount: { increment: 1 } },
      });
      return p;
    });

    // Notify client
    createNotification({
      userId:    project.clientId,
      type:      "NEW_PROPOSAL",
      title:     "عرض جديد على مشروعك",
      body:      `تلقيت عرضاً بقيمة $${data.bidAmount} على مشروعك`,
      actionUrl: `/projects/${params.id}/proposals`,
    }).catch(console.error);

    return created({ ...proposal, bidAmount: parseFloat(proposal.bidAmount.toString()), aiMatchScore });
  } catch (e) {
    return serverError(e);
  }
}
