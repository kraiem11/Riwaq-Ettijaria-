// ╔══════════════════════════════════════════════════════════╗
// ║  POST /api/reviews   — Submit a review after completion  ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, createNotification } from "@/lib/auth";
import { created, err, forbidden, notFound, serverError, parseBody } from "@/lib/api";
import { CreateReviewSchema } from "@/lib/validations";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, CreateReviewSchema);
  if (error) return error;

  try {
    const contract = await prisma.contract.findUnique({
      where:  { id: data.contractId, status: "COMPLETED" },
      select: { clientId: true, freelancerId: true },
    });

    if (!contract) return notFound("العقد أو لم يكتمل بعد");

    const isClient     = contract.clientId     === auth.sub;
    const isFreelancer = contract.freelancerId  === auth.sub;
    if (!isClient && !isFreelancer) return forbidden();

    // Determine reviewee
    const revieweeId = isClient ? contract.freelancerId : contract.clientId;

    // Check duplicate
    const existing = await prisma.review.findFirst({
      where: { contractId: data.contractId, reviewerId: auth.sub },
    });
    if (existing) return err("لقد أضفت تقييماً على هذا العقد مسبقاً", 409);

    // AI moderation — check for fake/spam reviews
    let aiScore = 100;
    if (data.comment) {
      try {
        const modResponse = await anthropic.messages.create({
          model:      "claude-sonnet-4-20250514",
          max_tokens: 200,
          messages:   [{
            role:    "user",
            content: `هل هذا التقييم حقيقي وموضوعي أم مشبوه؟ أجب برقم فقط من 0-100 (100 = حقيقي تماماً):\n"${data.comment}"`,
          }],
        });
        const scoreText = modResponse.content[0]?.type === "text" ? modResponse.content[0].text.trim() : "80";
        aiScore = Math.min(100, Math.max(0, parseInt(scoreText) || 80));
      } catch { /* don't block review on AI failure */ }
    }

    const review = await prisma.$transaction(async (tx) => {
      const r = await tx.review.create({
        data: {
          contractId:       data.contractId,
          reviewerId:       auth.sub,
          revieweeId,
          overallRating:    data.overallRating,
          communication:    data.communication,
          quality:          data.quality,
          timeliness:       data.timeliness,
          professionalism:  data.professionalism,
          comment:          data.comment,
          aiModerationScore: aiScore,
          isPublic:         aiScore >= 40, // hide suspected fake reviews
        },
      });

      // Recalculate reviewee's average rating
      const stats = await tx.review.aggregate({
        where:   { revieweeId, isPublic: true },
        _avg:    { overallRating: true },
        _count:  { id: true },
      });

      await tx.user.update({
        where: { id: revieweeId },
        data:  {
          avgRating:   stats._avg.overallRating ?? data.overallRating,
          reviewCount: stats._count.id,
        },
      });

      return r;
    });

    createNotification({
      userId:    revieweeId,
      type:      "REVIEW_RECEIVED",
      title:     "⭐ تلقيت تقييماً جديداً",
      body:      `حصلت على تقييم ${data.overallRating}/5 على مشروعك المكتمل`,
      actionUrl: `/profile`,
    }).catch(console.error);

    return created({ reviewId: review.id, aiModerated: aiScore >= 40, message: "تم إضافة تقييمك بنجاح" });
  } catch (e) {
    return serverError(e);
  }
}
