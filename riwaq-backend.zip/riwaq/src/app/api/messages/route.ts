// ╔═══════════════════════════════════════════════════════════╗
// ║  GET  /api/messages?contractId=  — paginated history     ║
// ║  POST /api/messages              — send message          ║
// ╚═══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest } from "@/lib/auth";
import { ok, created, err, forbidden, notFound, serverError, parseBody, buildPagination, paginationSkip } from "@/lib/api";
import { SendMessageSchema } from "@/lib/validations";
import { z } from "zod";

const QuerySchema = z.object({
  contractId: z.string().uuid(),
  page:  z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(50),
});

export async function GET(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const params: Record<string, string> = {};
  req.nextUrl.searchParams.forEach((v, k) => { params[k] = v; });
  const parsed = QuerySchema.safeParse(params);
  if (!parsed.success) return err("contractId مطلوب");

  const { contractId, page, limit } = parsed.data;

  try {
    // Verify user is part of this contract
    const contract = await prisma.contract.findUnique({
      where:  { id: contractId },
      select: { clientId: true, freelancerId: true },
    });

    if (!contract) return notFound("العقد");
    if (contract.clientId !== auth.sub && contract.freelancerId !== auth.sub && auth.role !== "ADMIN") {
      return forbidden("لا يمكنك الوصول إلى رسائل هذا العقد");
    }

    const [messages, total] = await Promise.all([
      prisma.message.findMany({
        where:   { contractId, deletedAt: null },
        skip:    paginationSkip(page, limit),
        take:    limit,
        orderBy: { createdAt: "asc" },
        include: {
          sender: { select: { id: true, displayName: true, avatarUrl: true } },
        },
      }),
      prisma.message.count({ where: { contractId, deletedAt: null } }),
    ]);

    // Mark unread messages as read
    await prisma.message.updateMany({
      where: { contractId, senderId: { not: auth.sub }, readAt: null },
      data:  { readAt: new Date() },
    });

    return ok(messages, buildPagination(page, limit, total));
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, SendMessageSchema);
  if (error) return error;

  try {
    const contract = await prisma.contract.findUnique({
      where:  { id: data.contractId },
      select: { clientId: true, freelancerId: true, status: true },
    });

    if (!contract) return notFound("العقد");
    if (contract.clientId !== auth.sub && contract.freelancerId !== auth.sub) return forbidden();
    if (contract.status === "CANCELLED") return err("لا يمكن إرسال رسائل على عقد ملغى");

    const message = await prisma.message.create({
      data: {
        contractId:  data.contractId,
        senderId:    auth.sub,
        content:     data.content,
        type:        (data.type ?? "TEXT") as any,
        attachments: data.attachments ?? [],
      },
      include: {
        sender: { select: { id: true, displayName: true, avatarUrl: true } },
      },
    });

    return created(message);
  } catch (e) {
    return serverError(e);
  }
}
