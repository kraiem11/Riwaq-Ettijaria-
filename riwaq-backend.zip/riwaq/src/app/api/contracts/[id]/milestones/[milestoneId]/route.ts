// ╔══════════════════════════════════════════════════════════╗
// ║  PATCH /api/contracts/:id/milestones/:milestoneId        ║
// ║  Submit / Request revision / Approve milestone           ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, createNotification } from "@/lib/auth";
import { ok, err, forbidden, notFound, serverError, parseBody } from "@/lib/api";
import { z } from "zod";

const MilestoneActionSchema = z.discriminatedUnion("action", [
  z.object({
    action:       z.literal("SUBMIT"),
    note:         z.string().max(2000).optional(),
    attachments:  z.array(z.string().url()).max(10).optional(),
  }),
  z.object({
    action:      z.literal("APPROVE"),
    note:        z.string().max(1000).optional(),
  }),
  z.object({
    action:      z.literal("REQUEST_REVISION"),
    note:        z.string().min(20, "يجب توضيح سبب طلب المراجعة").max(2000),
  }),
]);

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string; milestoneId: string } }
) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, MilestoneActionSchema);
  if (error) return error;

  try {
    const contract = await prisma.contract.findUnique({
      where:  { id: params.id },
      select: { clientId: true, freelancerId: true, status: true },
    });
    if (!contract) return notFound("العقد");
    if (contract.status !== "ACTIVE") return err("العقد غير نشط");

    const milestone = await prisma.milestone.findUnique({
      where:  { id: params.milestoneId, contractId: params.id },
      select: { id: true, title: true, status: true, revisionCount: true },
    });
    if (!milestone) return notFound("المرحلة");

    // ── SUBMIT (freelancer action) ────────────────────────
    if (data.action === "SUBMIT") {
      if (contract.freelancerId !== auth.sub) return forbidden("يمكن للمستقل فقط تسليم المراحل");
      if (!["PENDING", "IN_PROGRESS"].includes(milestone.status)) {
        return err("لا يمكن تسليم هذه المرحلة في حالتها الحالية");
      }

      await prisma.milestone.update({
        where: { id: params.milestoneId },
        data:  {
          status:         "SUBMITTED",
          submittedAt:    new Date(),
          submissionNote: data.note,
          attachments:    data.attachments ?? [],
        },
      });

      createNotification({
        userId:    contract.clientId,
        type:      "MILESTONE_SUBMITTED",
        title:     "📦 تم تسليم مرحلة للمراجعة",
        body:      `المستقل سلّم المرحلة "${milestone.title}" وتنتظر موافقتك`,
        actionUrl: `/contracts/${params.id}`,
      }).catch(console.error);

      return ok({ message: "تم تسليم المرحلة بنجاح، في انتظار مراجعة العميل" });
    }

    // ── APPROVE (client action) ───────────────────────────
    if (data.action === "APPROVE") {
      if (contract.clientId !== auth.sub) return forbidden("يمكن للعميل فقط الموافقة على المراحل");
      if (milestone.status !== "SUBMITTED") return err("المرحلة لم تُسلَّم بعد");

      await prisma.milestone.update({
        where: { id: params.milestoneId },
        data:  { status: "APPROVED", reviewedAt: new Date(), reviewNote: data.note },
      });

      // Check if all milestones are approved → complete contract
      const pending = await prisma.milestone.count({
        where: { contractId: params.id, status: { not: "APPROVED" } },
      });
      if (pending === 0) {
        await prisma.contract.update({ where: { id: params.id }, data: { status: "COMPLETED", actualEndDate: new Date() } });
        await prisma.project.update({ where: { id: params.id }, data: { status: "COMPLETED" } });
      }

      createNotification({
        userId:    contract.freelancerId,
        type:      "MILESTONE_APPROVED",
        title:     "✅ تمت الموافقة على مرحلتك",
        body:      `وافق العميل على المرحلة "${milestone.title}"`,
        actionUrl: `/contracts/${params.id}`,
      }).catch(console.error);

      return ok({ message: "تمت الموافقة على المرحلة بنجاح", contractComplete: pending === 0 });
    }

    // ── REQUEST_REVISION (client action) ─────────────────
    if (data.action === "REQUEST_REVISION") {
      if (contract.clientId !== auth.sub) return forbidden();
      if (milestone.status !== "SUBMITTED") return err("المرحلة لم تُسلَّم بعد");
      if (milestone.revisionCount >= 3) return err("تم استنفاد الحد الأقصى لطلبات المراجعة (٣ مرات)");

      await prisma.milestone.update({
        where: { id: params.milestoneId },
        data:  {
          status:        "REVISION_REQUESTED",
          reviewedAt:    new Date(),
          reviewNote:    data.note,
          revisionCount: { increment: 1 },
        },
      });

      createNotification({
        userId:    contract.freelancerId,
        type:      "MILESTONE_SUBMITTED",
        title:     "🔄 طُلبت مراجعة على مرحلتك",
        body:      `طلب العميل تعديلات على "${milestone.title}": ${data.note.slice(0, 100)}`,
        actionUrl: `/contracts/${params.id}`,
      }).catch(console.error);

      return ok({ message: "تم إرسال طلب المراجعة للمستقل", revisionsRemaining: 3 - milestone.revisionCount - 1 });
    }

  } catch (e) {
    return serverError(e);
  }
}
