// ╔══════════════════════════════════════════════════════════╗
// ║  GET   /api/contracts/:id   — Full contract details      ║
// ║  PATCH /api/contracts/:id   — Update status              ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest } from "@/lib/auth";
import { ok, err, forbidden, notFound, serverError } from "@/lib/api";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  try {
    const contract = await prisma.contract.findUnique({
      where: { id: params.id },
      include: {
        project:    { select: { id: true, title: true, description: true, category: true, skills: true } },
        client:     { select: { id: true, username: true, displayName: true, avatarUrl: true, country: true, avgRating: true } },
        freelancer: { select: { id: true, username: true, displayName: true, avatarUrl: true, country: true, avgRating: true, skills: { select: { skill: true, level: true } } } },
        milestones: { orderBy: { sortOrder: "asc" } },
        escrow:     { select: { id: true, amountFils: true, platformFeeFils: true, status: true, fundedAt: true, releasedAt: true } },
        review:     { select: { id: true, overallRating: true, comment: true, createdAt: true } },
        dispute:    { select: { id: true, status: true, outcome: true } },
      },
    });

    if (!contract) return notFound("العقد");

    const isParticipant = contract.clientId === auth.sub || contract.freelancerId === auth.sub;
    if (!isParticipant && auth.role !== "ADMIN") return forbidden();

    return ok({
      ...contract,
      totalAmount:    parseFloat(contract.totalAmount.toString()),
      platformFee:    parseFloat(contract.platformFee.toString()),
      freelancerNet:  parseFloat(contract.freelancerNet.toString()),
      milestones: contract.milestones.map(m => ({
        ...m,
        amount: parseFloat(m.amount.toString()),
      })),
      escrow: contract.escrow.map(e => ({
        ...e,
        amount:     Number(e.amountFils) / 100,
        platformFee: Number(e.platformFeeFils) / 100,
      })),
    });
  } catch (e) {
    return serverError(e);
  }
}
