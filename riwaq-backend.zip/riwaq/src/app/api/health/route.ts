// ╔══════════════════════════════════════════════════════════╗
// ║  GET /api/health   — Liveness + DB probe                 ║
// ╚══════════════════════════════════════════════════════════╝
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET() {
  const start = Date.now();
  try {
    await prisma.$queryRaw`SELECT 1`;
    return NextResponse.json({
      status:   "ok",
      db:       "connected",
      latencyMs: Date.now() - start,
      env:      process.env.NODE_ENV,
      version:  process.env.npm_package_version ?? "1.0.0",
      ts:       new Date().toISOString(),
    });
  } catch {
    return NextResponse.json({ status: "error", db: "disconnected" }, { status: 503 });
  }
}
