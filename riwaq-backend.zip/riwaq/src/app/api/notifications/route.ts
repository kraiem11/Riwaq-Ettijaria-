// ╔═══════════════════════════════════════════════════════╗
// ║  GET   /api/notifications         — paginated list   ║
// ║  PATCH /api/notifications         — mark all as read ║
// ╚═══════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest } from "@/lib/auth";
import { ok, err, serverError, buildPagination, paginationSkip } from "@/lib/api";
import { z } from "zod";

const QuerySchema = z.object({
  page:   z.coerce.number().int().positive().default(1),
  limit:  z.coerce.number().int().positive().max(50).default(20),
  unread: z.enum(["true","false"]).optional(),
});

export async function GET(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const params: Record<string,string> = {};
  req.nextUrl.searchParams.forEach((v,k) => { params[k]=v; });
  const parsed = QuerySchema.safeParse(params);
  if (!parsed.success) return err("معاملات غير صالحة");
  const { page, limit, unread } = parsed.data;

  try {
    const where: any = { userId: auth.sub };
    if (unread === "true") where.readAt = null;

    const [notifs, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where, skip: paginationSkip(page, limit), take: limit,
        orderBy: { createdAt: "desc" },
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId: auth.sub, readAt: null } }),
    ]);

    return ok({ notifications: notifs, unreadCount }, buildPagination(page, limit, total));
  } catch (e) {
    return serverError(e);
  }
}

export async function PATCH(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);
  try {
    const { count } = await prisma.notification.updateMany({
      where: { userId: auth.sub, readAt: null },
      data:  { readAt: new Date() },
    });
    return ok({ marked: count, message: `تم تعليم ${count} إشعار كمقروء` });
  } catch (e) {
    return serverError(e);
  }
}
