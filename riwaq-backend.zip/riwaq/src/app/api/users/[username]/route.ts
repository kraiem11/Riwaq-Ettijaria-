// ╔══════════════════════════════════════════════════════════╗
// ║  GET /api/users/:username   — Public profile             ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { ok, notFound, serverError } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { username: string } }) {
  try {
    const user = await prisma.user.findUnique({
      where:  { username: params.username, status: "ACTIVE", deletedAt: null },
      select: {
        id: true, username: true, displayName: true, avatarUrl: true, coverUrl: true,
        bio: true, tagline: true, role: true, country: true, city: true,
        avgRating: true, reviewCount: true, completedJobs: true, successRate: true,
        hourlyRate: true, availability: true, responseTime: true, level: true,
        createdAt: true,
        skills:      { select: { skill: true, level: true, yearsExp: true, endorsed: true }, orderBy: { sortOrder: "asc" } },
        languages:   { select: { language: true, proficiency: true } },
        certificates:{ select: { name: true, issuer: true, issueDate: true, verified: true } },
        portfolio:   { select: { title: true, description: true, imageUrls: true, skills: true, projectUrl: true }, orderBy: { sortOrder: "asc" }, take: 8 },
        reviews: {
          where:   { isPublic: true },
          orderBy: { createdAt: "desc" },
          take:    6,
          select: {
            overallRating: true, communication: true, quality: true, comment: true, createdAt: true,
            reviewer: { select: { displayName: true, avatarUrl: true, country: true } },
          },
        },
      },
    });

    if (!user) return notFound("المستخدم");

    return ok({
      ...user,
      hourlyRate:  user.hourlyRate  ? parseFloat(user.hourlyRate.toString())  : null,
      avgRating:   parseFloat(user.avgRating.toString()),
      successRate: parseFloat(user.successRate.toString()),
      reviews: user.reviews.map(r => ({
        ...r,
        overallRating: parseFloat(r.overallRating.toString()),
        communication: parseFloat(r.communication.toString()),
        quality:       parseFloat(r.quality.toString()),
      })),
    });
  } catch (e) {
    return serverError(e);
  }
}
