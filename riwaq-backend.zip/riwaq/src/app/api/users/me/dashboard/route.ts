// ╔══════════════════════════════════════════════════════════╗
// ║  GET /api/users/me/dashboard                             ║
// ║  Returns role-specific aggregated dashboard data         ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, canActAsClient, canActAsFreelancer } from "@/lib/auth";
import { ok, err, serverError, filsToAmount } from "@/lib/api";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

export async function GET(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const mode = req.nextUrl.searchParams.get("mode") ?? "client"; // "client" | "freelancer"

  try {
    if (mode === "client" && canActAsClient(auth.role)) {
      return ok(await buildClientDashboard(auth.sub));
    }
    if (mode === "freelancer" && canActAsFreelancer(auth.role)) {
      return ok(await buildFreelancerDashboard(auth.sub));
    }
    return err("نوع لوحة التحكم غير متوافق مع دورك");
  } catch (e) {
    return serverError(e);
  }
}

async function buildClientDashboard(userId: string) {
  const [activeProjects, recentProposals, spending, rating, wallet] = await Promise.all([
    // Active projects with proposal counts
    prisma.project.findMany({
      where:   { clientId: userId, status: { in: ["OPEN","IN_PROGRESS","IN_REVIEW"] }, deletedAt: null },
      orderBy: { createdAt: "desc" },
      take:    5,
      select:  {
        id: true, title: true, status: true, proposalCount: true, createdAt: true,
        budgetMin: true, budgetMax: true, deadline: true,
        _count: { select: { proposals: { where: { status: "PENDING" } } } },
      },
    }),
    // Recent proposals across all projects
    prisma.proposal.findMany({
      where:   { project: { clientId: userId } },
      orderBy: { createdAt: "desc" },
      take:    6,
      include: {
        freelancer: { select: { id: true, displayName: true, avatarUrl: true, avgRating: true, completedJobs: true } },
        project:    { select: { id: true, title: true } },
      },
    }),
    // Total spent this month
    prisma.transaction.aggregate({
      where: {
        userId,
        type:      "ESCROW_FUND",
        createdAt: { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) },
      },
      _sum: { amountFils: true },
    }),
    // Average rating given to client by freelancers
    prisma.review.aggregate({
      where: { revieweeId: userId },
      _avg:  { overallRating: true },
      _count: { id: true },
    }),
    // Wallet
    prisma.wallet.findUnique({ where: { userId } }),
  ]);

  // AI-powered insights (non-blocking)
  let aiInsights: string[] = [];
  try {
    const projectTitles = activeProjects.map(p => p.title).join(", ");
    const pendingCount  = recentProposals.filter(p => p.status === "PENDING").length;

    const res = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514", max_tokens: 400,
      messages: [{
        role: "user",
        content: `أنت مساعد لوحة تحكم رواق. بناءً على هذه البيانات:
- مشاريع نشطة: ${activeProjects.length}
- عروض معلقة للمراجعة: ${pendingCount}
- المشاريع: ${projectTitles.slice(0, 200)}
أعطِ 3 توصيات قصيرة وعملية باللغة العربية (جملة واحدة لكل توصية).
أجب فقط بـ JSON: {"insights": ["توصية 1", "توصية 2", "توصية 3"]}`,
      }],
    });

    const raw = res.content[0]?.type === "text" ? res.content[0].text.replace(/```json|```/g,"").trim() : "{}";
    aiInsights = JSON.parse(raw).insights ?? [];
  } catch { /* non-critical */ }

  return {
    activeProjects: activeProjects.map(p => ({
      ...p,
      budgetMin:    parseFloat(p.budgetMin.toString()),
      budgetMax:    parseFloat(p.budgetMax.toString()),
      newProposals: p._count.proposals,
    })),
    recentProposals: recentProposals.map(p => ({
      ...p,
      bidAmount:  parseFloat(p.bidAmount.toString()),
      freelancer: { ...p.freelancer, avgRating: parseFloat(p.freelancer.avgRating.toString()) },
    })),
    stats: {
      totalActiveProjects: activeProjects.length,
      totalNewProposals:   recentProposals.filter(p => p.status === "PENDING").length,
      monthlySpent:        filsToAmount(spending._sum.amountFils ?? 0n),
      avgRating:           rating._avg.overallRating ? parseFloat(rating._avg.overallRating.toString()) : null,
      reviewCount:         rating._count.id,
    },
    wallet: wallet ? {
      balance: filsToAmount(wallet.balanceFils),
      escrow:  filsToAmount(wallet.escrowFils),
      pending: filsToAmount(wallet.pendingFils),
    } : null,
    aiInsights,
  };
}

async function buildFreelancerDashboard(userId: string) {
  const now   = new Date();
  const month = new Date(now.getFullYear(), now.getMonth(), 1);

  const [myBids, earnings, earningsHistory, matchedProjects, user] = await Promise.all([
    // My recent bids
    prisma.proposal.findMany({
      where:   { freelancerId: userId },
      orderBy: { createdAt: "desc" },
      take:    6,
      include: { project: { select: { id: true, title: true, status: true, budgetMin: true, budgetMax: true } } },
    }),
    // This month's earnings
    prisma.transaction.aggregate({
      where:  { userId, type: "ESCROW_RELEASE", createdAt: { gte: month } },
      _sum:   { amountFils: true },
    }),
    // Last 6 months earnings chart
    Promise.all(Array.from({ length: 6 }, (_, i) => {
      const d   = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
      const end = new Date(now.getFullYear(), now.getMonth() - (4 - i), 1);
      return prisma.transaction.aggregate({
        where: { userId, type: "ESCROW_RELEASE", createdAt: { gte: d, lt: end } },
        _sum:  { amountFils: true },
      }).then(r => ({
        month:  d.toLocaleString("ar-SA", { month: "short" }),
        amount: filsToAmount(r._sum.amountFils ?? 0n),
      }));
    })),
    // AI-matched open projects
    prisma.project.findMany({
      where: {
        status:    "OPEN",
        deletedAt: null,
        skills:    { hasSome: await prisma.userSkill.findMany({ where: { userId }, select: { skill: true } }).then(ss => ss.map(s => s.skill)) },
        proposals: { none: { freelancerId: userId } }, // not already bid
      },
      orderBy: { publishedAt: "desc" },
      take:    8,
      select: {
        id: true, title: true, description: true, skills: true, category: true,
        budgetType: true, budgetMin: true, budgetMax: true, timeline: true,
        proposalCount: true, publishedAt: true,
        client: { select: { displayName: true, avgRating: true, country: true } },
      },
    }),
    // User stats
    prisma.user.findUnique({
      where:  { id: userId },
      select: { avgRating: true, reviewCount: true, completedJobs: true, successRate: true, level: true },
    }),
  ]);

  return {
    stats: {
      monthlyEarnings: filsToAmount(earnings._sum.amountFils ?? 0n),
      activeBids:      myBids.filter(b => b.status === "PENDING").length,
      avgRating:       user ? parseFloat(user.avgRating.toString()) : 0,
      completedJobs:   user?.completedJobs ?? 0,
      successRate:     user ? parseFloat(user.successRate.toString()) : 0,
      level:           user?.level ?? 1,
    },
    earningsHistory,
    recentBids: myBids.map(b => ({
      ...b,
      bidAmount: parseFloat(b.bidAmount.toString()),
      project:   { ...b.project, budgetMin: parseFloat(b.project.budgetMin.toString()), budgetMax: parseFloat(b.project.budgetMax.toString()) },
    })),
    matchedProjects: matchedProjects.map(p => ({
      ...p,
      budgetMin: parseFloat(p.budgetMin.toString()),
      budgetMax: parseFloat(p.budgetMax.toString()),
    })),
  };
}
