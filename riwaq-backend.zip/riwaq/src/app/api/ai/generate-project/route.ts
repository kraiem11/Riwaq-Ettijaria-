// ╔══════════════════════════════════════════════════════════╗
// ║  POST /api/ai/generate-project                          ║
// ║  Calls Claude API to generate a full project brief      ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { getAuthFromRequest, canActAsClient } from "@/lib/auth";
import { ok, err, forbidden, serverError, parseBody } from "@/lib/api";
import { GenerateProjectSchema } from "@/lib/validations";
import type { GeneratedProject } from "@/types";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

const SYSTEM_PROMPT = `أنت خبير في صياغة مشاريع العمل الحر الاحترافية باللغة العربية.
مهمتك: تحويل فكرة المستخدم البسيطة إلى مشروع احترافي كامل وجاهز للنشر على منصة رواق.

قواعد صارمة:
1. أجب فقط بـ JSON صحيح — بدون أي نص إضافي أو markdown أو backticks
2. الوصف يجب أن يكون 150-250 كلمة، احترافي، واضح، ومحدد
3. المهارات: 4-7 مهارات تقنية دقيقة ومتعلقة بالمشروع
4. الميزانية: واقعية حسب معايير السوق العربي (بالدولار)
5. التصنيف: اختر الأنسب من القائمة المتاحة

تنسيق الإجابة:
{
  "title": "عنوان مشروع احترافي واضح (أقل من 80 حرف)",
  "description": "وصف شامل ومحدد يتضمن: الهدف، المتطلبات، النتائج المتوقعة، ومعايير القبول",
  "skills": ["مهارة1", "مهارة2", "مهارة3", "مهارة4"],
  "budgetMin": 500,
  "budgetMax": 1500,
  "timeline": "2w",
  "category": "WEB_DEVELOPMENT"
}

قيم timeline المتاحة فقط: "1w" | "2w" | "1m" | "3m+"
قيم category المتاحة فقط: "WEB_DEVELOPMENT" | "MOBILE_DEVELOPMENT" | "GRAPHIC_DESIGN" | "UI_UX_DESIGN" | "CONTENT_WRITING" | "TRANSLATION" | "DIGITAL_MARKETING" | "SEO" | "VIDEO_EDITING" | "MOTION_GRAPHICS" | "DATA_ANALYSIS" | "AI_ML" | "PHOTOGRAPHY" | "VOICE_OVER" | "OTHER"`;

export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);
  if (!canActAsClient(auth.role)) return forbidden("هذه الميزة متاحة للعملاء فقط");

  const { data, error } = await parseBody(req, GenerateProjectSchema);
  if (error) return error;

  try {
    const userMessage = data.category
      ? `فكرة المشروع: ${data.prompt}\nالتصنيف المفضل: ${data.category}`
      : `فكرة المشروع: ${data.prompt}`;

    const message = await anthropic.messages.create({
      model:      "claude-sonnet-4-20250514",
      max_tokens: 1500,
      system:     SYSTEM_PROMPT,
      messages:   [{ role: "user", content: userMessage }],
    });

    const rawText = message.content
      .filter(b => b.type === "text")
      .map(b => (b as { type: "text"; text: string }).text)
      .join("")
      .replace(/```json|```/g, "")
      .trim();

    let generated: GeneratedProject;
    try {
      generated = JSON.parse(rawText);
    } catch {
      return err("تعذّر تحليل استجابة الذكاء الاصطناعي. يرجى المحاولة مجدداً.");
    }

    // Validate the generated structure
    const requiredFields = ["title", "description", "skills", "budgetMin", "budgetMax", "timeline", "category"];
    const missing = requiredFields.filter(f => !(f in generated));
    if (missing.length > 0) {
      return err(`الاستجابة غير مكتملة: ${missing.join(", ")}`);
    }

    // Log usage (optional telemetry)
    console.log(`[AI] Project generated for user ${auth.sub} | tokens: ${message.usage.input_tokens + message.usage.output_tokens}`);

    return ok({
      generated,
      tokensUsed: message.usage.input_tokens + message.usage.output_tokens,
      model:      message.model,
    });

  } catch (e: any) {
    if (e?.status === 529) return err("خدمة الذكاء الاصطناعي مشغولة حالياً. يرجى المحاولة بعد لحظات.", 503);
    if (e?.status === 401) return err("مفتاح API غير صالح", 500);
    return serverError(e);
  }
}
