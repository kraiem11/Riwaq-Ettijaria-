// ╔══════════════════════════════════════════════════════════╗
// ║  POST /api/ai/match-freelancers                         ║
// ║  AI-powered freelancer matching for a project           ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import prisma from "@/lib/prisma";
import { getAuthFromRequest } from "@/lib/auth";
import { ok, err, forbidden, notFound, serverError, parseBody } from "@/lib/api";
import { MatchFreelancersSchema } from "@/lib/validations";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, MatchFreelancersSchema);
  if (error) return error;

  try {
    // Fetch project details
    const project = await prisma.project.findUnique({
      where:  { id: data.projectId, deletedAt: null },
      select: {
        id: true, clientId: true, title: true, description: true,
        skills: true, budgetMin: true, budgetMax: true,
        category: true, experienceLevel: true, timeline: true,
      },
    });

    if (!project) return notFound("المشروع");
    if (project.clientId !== auth.sub && auth.role !== "ADMIN") return forbidden();

    // Fetch candidate freelancers (skill-filtered, active, not already proposed)
    const existingProposers = await prisma.proposal.findMany({
      where:  { projectId: data.projectId },
      select: { freelancerId: true },
    });
    const excludeIds = existingProposers.map(p => p.freelancerId);

    const candidates = await prisma.user.findMany({
      where: {
        status:    "ACTIVE",
        role:      { in: ["FREELANCER", "BOTH"] },
        id:        { notIn: [...excludeIds, auth.sub] },
        skills:    { some: { skill: { in: project.skills } } },
      },
      take: 20, // pre-filter pool for AI
      orderBy: [{ avgRating: "desc" }, { completedJobs: "desc" }],
      select: {
        id: true, username: true, displayName: true, avatarUrl: true,
        bio: true, tagline: true, country: true,
        avgRating: true, reviewCount: true, completedJobs: true, successRate: true,
        hourlyRate: true, availability: true, responseTime: true, level: true,
        skills: { select: { skill: true, level: true, yearsExp: true } },
      },
    });

    if (candidates.length === 0) {
      return ok({ matches: [], message: "لا يوجد مستقلون مؤهلون حالياً" });
    }

    // Build AI prompt for intelligent ranking
    const candidateSummaries = candidates.map((c, i) => ({
      index:         i,
      displayName:   c.displayName,
      skills:        c.skills.map(s => `${s.skill}(lvl${s.level})`).join(", "),
      avgRating:     parseFloat(c.avgRating.toString()),
      completedJobs: c.completedJobs,
      successRate:   parseFloat(c.successRate.toString()),
      hourlyRate:    c.hourlyRate ? parseFloat(c.hourlyRate.toString()) : null,
      availability:  c.availability,
      country:       c.country,
    }));

    const aiPrompt = `
أنت نظام مطابقة ذكي لمنصة رواق للعمل الحر.

المشروع:
- العنوان: ${project.title}
- المتطلبات: ${project.description.slice(0, 300)}
- المهارات المطلوبة: ${project.skills.join(", ")}
- الميزانية: $${project.budgetMin}–$${project.budgetMax}
- الجدول الزمني: ${project.timeline}
- مستوى الخبرة: ${project.experienceLevel}

المرشحون (${candidates.length} مستقل):
${JSON.stringify(candidateSummaries, null, 2)}

المطلوب: رتّب أفضل ${Math.min(data.limit, candidates.length)} مستقلين وأعطِ لكل منهم:
1. درجة التوافق (0-100)
2. أسباب التوصية (3 نقاط)
3. تقدير التكلفة

أجب فقط بـ JSON:
{
  "rankings": [
    {
      "index": 0,
      "matchScore": 95,
      "matchReasons": ["سبب 1", "سبب 2", "سبب 3"],
      "estimatedCost": 1200
    }
  ]
}`;

    const aiResponse = await anthropic.messages.create({
      model:      "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages:   [{ role: "user", content: aiPrompt }],
    });

    const rawText = aiResponse.content
      .filter(b => b.type === "text")
      .map(b => (b as any).text)
      .join("")
      .replace(/```json|```/g, "")
      .trim();

    let aiResult: { rankings: Array<{ index: number; matchScore: number; matchReasons: string[]; estimatedCost: number }> };
    try {
      aiResult = JSON.parse(rawText);
    } catch {
      // Fallback: basic sorting without AI
      const matches = candidates.slice(0, data.limit).map(c => ({
        freelancer:    { ...c, avgRating: parseFloat(c.avgRating.toString()), hourlyRate: c.hourlyRate ? parseFloat(c.hourlyRate.toString()) : null },
        matchScore:    parseFloat(c.avgRating.toString()) * 20,
        matchReasons:  ["تقييم مرتفع", "خبرة موثّقة", "مهارات متوافقة"],
        estimatedCost: null,
      }));
      return ok({ matches, aiPowered: false });
    }

    // Build final matches with full freelancer data
    const matches = aiResult.rankings
      .filter(r => r.index >= 0 && r.index < candidates.length)
      .map(r => ({
        freelancer:    {
          ...candidates[r.index],
          avgRating:  parseFloat(candidates[r.index].avgRating.toString()),
          hourlyRate: candidates[r.index].hourlyRate ? parseFloat(candidates[r.index].hourlyRate.toString()) : null,
        },
        matchScore:    r.matchScore,
        matchReasons:  r.matchReasons,
        estimatedCost: r.estimatedCost,
      }))
      .sort((a, b) => b.matchScore - a.matchScore);

    return ok({ matches, aiPowered: true, candidatesAnalyzed: candidates.length });

  } catch (e) {
    return serverError(e);
  }
}
