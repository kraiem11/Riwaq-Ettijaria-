// ╔═══════════════════════════════════════════════════════════╗
// ║  POST /api/payments/create-escrow                        ║
// ║  Initiates an escrow payment for a contract milestone    ║
// ╚═══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest } from "@/lib/auth";
import { ok, err, forbidden, notFound, serverError, parseBody, amountToFils, filsToAmount, calculatePlatformFee } from "@/lib/api";
import { CreateEscrowSchema } from "@/lib/validations";

export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, CreateEscrowSchema);
  if (error) return error;

  try {
    // Verify contract and permissions
    const contract = await prisma.contract.findUnique({
      where:  { id: data.contractId },
      select: { id: true, clientId: true, freelancerId: true, totalAmount: true, status: true, currency: true },
    });

    if (!contract) return notFound("العقد");
    if (contract.clientId !== auth.sub) return forbidden("يمكن للعميل فقط إنشاء ضمان الدفع");
    if (contract.status !== "ACTIVE") return err("العقد غير نشط");

    // Check wallet balance
    const wallet = await prisma.wallet.findUnique({ where: { userId: auth.sub } });
    if (!wallet || wallet.balanceFils < BigInt(data.amountFils)) {
      return err("رصيد المحفظة غير كافٍ لإتمام هذه العملية");
    }

    const amount      = filsToAmount(BigInt(data.amountFils));
    const { platformFee, freelancerNet } = calculatePlatformFee(amount);
    const feeFils     = amountToFils(platformFee);

    // Atomic transaction: deduct from wallet, create escrow
    const escrow = await prisma.$transaction(async (tx) => {
      // Deduct from client wallet
      await tx.wallet.update({
        where: { userId: auth.sub },
        data:  {
          balanceFils: { decrement: BigInt(data.amountFils) },
          escrowFils:  { increment: BigInt(data.amountFils) },
        },
      });

      // Create escrow record
      const newEscrow = await tx.escrow.create({
        data: {
          contractId:      data.contractId,
          clientId:        auth.sub,
          freelancerId:    contract.freelancerId,
          amountFils:      BigInt(data.amountFils),
          platformFeeFils: feeFils,
          status:          "FUNDED",
          gatewayProvider: data.gatewayProvider,
          fundedAt:        new Date(),
        },
      });

      // Log transaction
      const balanceAfter = wallet.balanceFils - BigInt(data.amountFils);
      await tx.transaction.create({
        data: {
          userId:           auth.sub,
          type:             "ESCROW_FUND",
          amountFils:       BigInt(data.amountFils),
          balanceAfterFils: balanceAfter,
          reference:        newEscrow.id,
          description:      `ضمان دفع للعقد ${data.contractId}`,
        },
      });

      return newEscrow;
    });

    return ok({
      escrowId:       escrow.id,
      amount:         amount,
      platformFee:    platformFee,
      freelancerNet:  freelancerNet,
      currency:       contract.currency,
      status:         "FUNDED",
      message:        "تم تأمين الدفع في حساب الضمان بنجاح",
    });
  } catch (e) {
    return serverError(e);
  }
}
