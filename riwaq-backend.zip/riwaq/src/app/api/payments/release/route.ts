// ╔═══════════════════════════════════════════════════════════╗
// ║  POST /api/payments/release                              ║
// ║  Client approves milestone → releases escrow funds      ║
// ╚═══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, createNotification } from "@/lib/auth";
import { ok, err, forbidden, notFound, serverError, parseBody, filsToAmount } from "@/lib/api";
import { ReleaseEscrowSchema } from "@/lib/validations";

export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, ReleaseEscrowSchema);
  if (error) return error;

  try {
    const [escrow, milestone] = await Promise.all([
      prisma.escrow.findUnique({
        where:  { id: data.escrowId },
        select: { id: true, clientId: true, freelancerId: true, amountFils: true, platformFeeFils: true, status: true, contractId: true },
      }),
      prisma.milestone.findUnique({
        where:  { id: data.milestoneId },
        select: { id: true, status: true, title: true, contractId: true },
      }),
    ]);

    if (!escrow)    return notFound("حساب الضمان");
    if (!milestone) return notFound("المرحلة");

    if (escrow.clientId     !== auth.sub)             return forbidden("يمكن للعميل فقط تحرير الدفع");
    if (escrow.status       !== "FUNDED")             return err("حساب الضمان غير ممول أو تم تحريره بالفعل");
    if (milestone.status    !== "SUBMITTED")          return err("المرحلة لم يتم تسليمها بعد لتحرير الدفع");
    if (milestone.contractId !== escrow.contractId)   return err("المرحلة لا تنتمي إلى هذا العقد");

    const freelancerAmountFils = escrow.amountFils - escrow.platformFeeFils;

    // Atomic release
    await prisma.$transaction(async (tx) => {
      // Credit freelancer wallet
      await tx.wallet.upsert({
        where:  { userId: escrow.freelancerId },
        update: { balanceFils: { increment: freelancerAmountFils } },
        create: { userId: escrow.freelancerId, balanceFils: freelancerAmountFils },
      });

      // Deduct from client's escrow balance
      await tx.wallet.update({
        where: { userId: auth.sub },
        data:  { escrowFils: { decrement: escrow.amountFils } },
      });

      // Update escrow status
      await tx.escrow.update({
        where: { id: data.escrowId },
        data:  { status: "RELEASED", releasedAt: new Date() },
      });

      // Update milestone status
      await tx.milestone.update({
        where: { id: data.milestoneId },
        data:  { status: "APPROVED", reviewedAt: new Date() },
      });

      // Log transactions
      const freelancerWallet = await tx.wallet.findUnique({ where: { userId: escrow.freelancerId } });
      await tx.transaction.create({
        data: {
          userId:           escrow.freelancerId,
          type:             "ESCROW_RELEASE",
          amountFils:       freelancerAmountFils,
          balanceAfterFils: freelancerWallet?.balanceFils ?? freelancerAmountFils,
          reference:        data.escrowId,
          description:      `دفع مرحلة: ${milestone.title}`,
        },
      });

      // Update freelancer total earnings
      await tx.user.update({
        where: { id: escrow.freelancerId },
        data:  { totalEarnings: { increment: freelancerAmountFils } },
      });
    });

    // Notify freelancer
    createNotification({
      userId:    escrow.freelancerId,
      type:      "PAYMENT_RECEIVED",
      title:     "💰 تم استلام دفعتك!",
      body:      `تم تحرير مبلغ ${filsToAmount(freelancerAmountFils)} ريال لمرحلة "${milestone.title}"`,
      actionUrl: `/contracts/${escrow.contractId}`,
    }).catch(console.error);

    return ok({
      message:        "تم تحرير الدفع بنجاح",
      releasedAmount: filsToAmount(freelancerAmountFils),
      platformFee:    filsToAmount(escrow.platformFeeFils),
      milestoneStatus: "APPROVED",
    });
  } catch (e) {
    return serverError(e);
  }
}
