// ╔══════════════════════════════════════════════════════════╗
// ║  GET    /api/proposals/:id                               ║
// ║  PATCH  /api/proposals/:id  — accept / reject / withdraw║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, createNotification, canActAsClient } from "@/lib/auth";
import { ok, err, forbidden, notFound, serverError, parseBody, calculatePlatformFee } from "@/lib/api";
import { z } from "zod";

const ActionSchema = z.object({
  action: z.enum(["ACCEPT", "REJECT", "SHORTLIST", "WITHDRAW"]),
  note:   z.string().max(1000).optional(),
});

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  try {
    const proposal = await prisma.proposal.findUnique({
      where:   { id: params.id },
      include: {
        freelancer: {
          select: {
            id: true, username: true, displayName: true, avatarUrl: true,
            bio: true, country: true, avgRating: true, reviewCount: true,
            completedJobs: true, successRate: true, hourlyRate: true, level: true,
            skills:    { select: { skill: true, level: true, yearsExp: true } },
            portfolio: { take: 4, select: { title: true, imageUrls: true, skills: true } },
          },
        },
        project: { select: { id: true, title: true, clientId: true } },
      },
    });

    if (!proposal) return notFound("العرض");

    // Only client or the freelancer can view
    const isClient     = proposal.project?.clientId === auth.sub;
    const isFreelancer = proposal.freelancerId === auth.sub;
    if (!isClient && !isFreelancer && auth.role !== "ADMIN") return forbidden();

    return ok({
      ...proposal,
      bidAmount: parseFloat(proposal.bidAmount.toString()),
    });
  } catch (e) {
    return serverError(e);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, ActionSchema);
  if (error) return error;

  try {
    const proposal = await prisma.proposal.findUnique({
      where:   { id: params.id },
      include: { project: { select: { id: true, clientId: true, title: true, status: true } } },
    });

    if (!proposal) return notFound("العرض");
    if (proposal.status === "ACCEPTED") return err("تم قبول هذا العرض بالفعل");

    // WITHDRAW — freelancer only
    if (data.action === "WITHDRAW") {
      if (proposal.freelancerId !== auth.sub) return forbidden();
      await prisma.proposal.update({ where: { id: params.id }, data: { status: "WITHDRAWN" } });
      return ok({ message: "تم سحب العرض بنجاح" });
    }

    // Client actions: ACCEPT / REJECT / SHORTLIST
    if (proposal.project?.clientId !== auth.sub) return forbidden("يمكن للعميل فقط قبول أو رفض العروض");
    if (proposal.project.status !== "OPEN" && data.action === "ACCEPT") {
      return err("لا يمكن قبول عروض على مشروع غير مفتوح");
    }

    if (data.action === "SHORTLIST") {
      await prisma.proposal.update({ where: { id: params.id }, data: { status: "SHORTLISTED", clientNote: data.note } });
      return ok({ message: "تمت إضافة العرض إلى القائمة المختصرة" });
    }

    if (data.action === "REJECT") {
      await prisma.proposal.update({ where: { id: params.id }, data: { status: "REJECTED", clientNote: data.note } });

      createNotification({
        userId:    proposal.freelancerId,
        type:      "PROPOSAL_REJECTED",
        title:     "تم رفض عرضك",
        body:      `للأسف لم يتم قبول عرضك على مشروع "${proposal.project.title}"`,
        actionUrl: `/proposals/${params.id}`,
      }).catch(console.error);

      return ok({ message: "تم رفض العرض" });
    }

    // ── ACCEPT: create contract + reject all others ──
    if (data.action === "ACCEPT") {
      const bidAmount = parseFloat(proposal.bidAmount.toString());
      const { platformFee, freelancerNet } = calculatePlatformFee(bidAmount);

      const contract = await prisma.$transaction(async (tx) => {
        // Create the contract
        const newContract = await tx.contract.create({
          data: {
            projectId:       proposal.projectId,
            proposalId:      proposal.id,
            clientId:        auth.sub,
            freelancerId:    proposal.freelancerId,
            totalAmount:     bidAmount,
            platformFee,
            freelancerNet,
            expectedEndDate: new Date(Date.now() + proposal.deliveryDays * 86_400_000),
          },
        });

        // Create milestones if provided
        if (proposal.milestones && Array.isArray(proposal.milestones)) {
          const mData = (proposal.milestones as any[]).map((m: any, i: number) => ({
            contractId:  newContract.id,
            title:       m.title,
            description: m.description,
            amount:      m.amount,
            dueDate:     m.dueDate ? new Date(m.dueDate) : null,
            sortOrder:   i,
          }));
          await tx.milestone.createMany({ data: mData });
        }

        // Accept this proposal
        await tx.proposal.update({ where: { id: params.id }, data: { status: "ACCEPTED" } });

        // Reject all other pending proposals for this project
        await tx.proposal.updateMany({
          where: { projectId: proposal.projectId, id: { not: params.id }, status: { in: ["PENDING", "SHORTLISTED"] } },
          data:  { status: "REJECTED" },
        });

        // Move project to IN_PROGRESS
        await tx.project.update({
          where: { id: proposal.projectId },
          data:  { status: "IN_PROGRESS" },
        });

        return newContract;
      });

      // Notify the accepted freelancer
      createNotification({
        userId:    proposal.freelancerId,
        type:      "PROPOSAL_ACCEPTED",
        title:     "🎉 تم قبول عرضك!",
        body:      `تهانينا! تم قبول عرضك على مشروع "${proposal.project.title}"`,
        actionUrl: `/contracts/${contract.id}`,
      }).catch(console.error);

      return ok({ message: "تم قبول العرض وإنشاء العقد بنجاح", contractId: contract.id });
    }

    return err("إجراء غير صالح");
  } catch (e) {
    return serverError(e);
  }
}
