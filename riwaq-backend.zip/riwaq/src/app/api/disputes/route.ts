// ╔══════════════════════════════════════════════════════════╗
// ║  GET  /api/disputes          — list user's disputes      ║
// ║  POST /api/disputes          — open a new dispute        ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import prisma from "@/lib/prisma";
import { getAuthFromRequest, createNotification } from "@/lib/auth";
import { ok, created, err, forbidden, notFound, serverError, parseBody } from "@/lib/api";
import { OpenDisputeSchema } from "@/lib/validations";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

export async function GET(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  try {
    const disputes = await prisma.dispute.findMany({
      where: {
        OR: [
          { contract: { clientId:     auth.sub } },
          { contract: { freelancerId: auth.sub } },
        ],
      },
      orderBy: { createdAt: "desc" },
      include: {
        contract: {
          select: {
            id: true, totalAmount: true, currency: true,
            project:    { select: { title: true } },
            client:     { select: { displayName: true, avatarUrl: true } },
            freelancer: { select: { displayName: true, avatarUrl: true } },
          },
        },
      },
    });
    return ok(disputes);
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: NextRequest) {
  const auth = await getAuthFromRequest(req);
  if (!auth) return err("غير مصرح", 401);

  const { data, error } = await parseBody(req, OpenDisputeSchema);
  if (error) return error;

  try {
    const contract = await prisma.contract.findUnique({
      where:   { id: data.contractId },
      include: {
        project:    { select: { title: true, description: true, skills: true } },
        milestones: { select: { title: true, status: true, amount: true, submittedAt: true } },
        client:     { select: { displayName: true } },
        freelancer: { select: { displayName: true } },
      },
    });

    if (!contract) return notFound("العقد");

    const isClient     = contract.clientId     === auth.sub;
    const isFreelancer = contract.freelancerId  === auth.sub;
    if (!isClient && !isFreelancer) return forbidden();
    if (!["ACTIVE", "IN_REVIEW"].includes(contract.status)) return err("لا يمكن فتح نزاع على هذا العقد حالياً");

    // Check no existing dispute
    const existing = await prisma.dispute.findUnique({ where: { contractId: data.contractId }, select: { id: true } });
    if (existing) return err("يوجد نزاع مفتوح بالفعل على هذا العقد", 409);

    const respondentId = isClient ? contract.freelancerId : contract.clientId;

    // Create dispute
    const dispute = await prisma.$transaction(async (tx) => {
      const d = await tx.dispute.create({
        data: {
          contractId:   data.contractId,
          initiatorId:  auth.sub,
          respondentId,
          reason:       data.reason,
          description:  data.description,
          evidence:     data.evidence ?? [],
          status:       "OPEN",
        },
      });
      // Freeze contract
      await tx.contract.update({ where: { id: data.contractId }, data: { status: "DISPUTED" } });
      // Freeze any funded escrow
      await tx.escrow.updateMany({ where: { contractId: data.contractId, status: "FUNDED" }, data: { status: "FROZEN" } });
      return d;
    });

    // Notify respondent
    createNotification({
      userId:    respondentId,
      type:      "DISPUTE_UPDATE",
      title:     "⚠️ تم فتح نزاع على عقدك",
      body:      `فُتح نزاع على مشروع "${contract.project?.title}". سيقوم AI بتحليل القضية خلال 24 ساعة.`,
      actionUrl: `/disputes/${dispute.id}`,
    }).catch(console.error);

    // Trigger AI arbitration asynchronously
    runAIArbitration(dispute.id, contract, data.description).catch(console.error);

    return created({
      disputeId: dispute.id,
      message:   "تم فتح النزاع بنجاح. سيقوم الذكاء الاصطناعي بتحليل القضية وإصدار حكم مبدئي خلال دقائق.",
      status:    "OPEN",
    });
  } catch (e) {
    return serverError(e);
  }
}

// ── AI Arbitration Engine ───────────────────────────────────
async function runAIArbitration(
  disputeId: string,
  contract:  any,
  description: string
): Promise<void> {
  try {
    const milestoneSummary = contract.milestones.map((m: any) =>
      `- ${m.title}: ${m.status} (${m.amount} SAR, تسليم: ${m.submittedAt ? "نعم" : "لا"})`
    ).join("\n");

    const prompt = `
أنت حكّم مستقل ونزيه لمنصة رواق للعمل الحر. عليك تحليل النزاع التالي وإصدار حكم عادل.

== تفاصيل العقد ==
المشروع: ${contract.project?.title}
وصف المشروع: ${contract.project?.description?.slice(0, 400)}
المهارات المطلوبة: ${contract.project?.skills?.join(", ")}
العميل: ${contract.client?.displayName}
المستقل: ${contract.freelancer?.displayName}
القيمة الإجمالية: ${contract.totalAmount} SAR

== حالة المراحل ==
${milestoneSummary}

== وصف النزاع ==
${description}

== مطلوب منك ==
حلّل القضية بموضوعية تامة وأصدر حكماً. أجب فقط بـ JSON:
{
  "recommendation": "CLIENT_WINS" | "FREELANCER_WINS" | "SPLIT",
  "confidence": 0-100,
  "summary": "ملخص الحكم بالعربية (200-300 كلمة)",
  "keyFindings": ["نتيجة 1", "نتيجة 2", "نتيجة 3"],
  "suggestedSplit": { "clientPercent": 40, "freelancerPercent": 60 }
}
ملاحظة: suggestedSplit مطلوب فقط عند اختيار SPLIT.`;

    const response = await anthropic.messages.create({
      model:      "claude-sonnet-4-20250514",
      max_tokens: 1200,
      messages:   [{ role: "user", content: prompt }],
    });

    const rawText = response.content
      .filter(b => b.type === "text")
      .map(b => (b as any).text)
      .join("")
      .replace(/```json|```/g, "")
      .trim();

    const ruling = JSON.parse(rawText);

    await prisma.dispute.update({
      where: { id: disputeId },
      data:  {
        aiAnalysis:        ruling.summary,
        aiRecommendation:  ruling.recommendation as any,
        aiConfidence:      ruling.confidence,
        aiRunAt:           new Date(),
        status:            "AI_RULED",
      },
    });

    // Notify both parties
    const dispute = await prisma.dispute.findUnique({
      where:   { id: disputeId },
      select:  { initiatorId: true, respondentId: true },
    });

    if (dispute) {
      const notif = {
        type:      "DISPUTE_UPDATE",
        title:     "🤖 صدر حكم الذكاء الاصطناعي",
        body:      `تم تحليل نزاعك وصدر حكم مبدئي. يمكنك طلب مراجعة بشرية خلال 48 ساعة.`,
        actionUrl: `/disputes/${disputeId}`,
      };
      await Promise.all([
        createNotification({ userId: dispute.initiatorId,  ...notif }),
        createNotification({ userId: dispute.respondentId, ...notif }),
      ]);
    }

  } catch (err) {
    console.error("[AI Arbitration] Error:", err);
    // Don't throw — let the dispute remain in OPEN state for admin review
  }
}
