// ╔══════════════════════════════════════════╗
// ║  رواق — Global TypeScript Types          ║
// ╚══════════════════════════════════════════╝

import type { User, Project, Proposal, Contract, Milestone } from "@prisma/client";

// ─── Auth ──────────────────────────────────
export interface JwtPayload {
  sub:   string;
  email: string;
  role:  string;
  iat:   number;
  exp:   number;
}

export interface AuthUser {
  id:          string;
  email:       string;
  username:    string;
  displayName: string;
  avatarUrl:   string | null;
  role:        string;
  kycLevel:    string;
}

// ─── API Responses ─────────────────────────
export interface ApiOk<T = unknown> {
  ok:   true;
  data: T;
  meta?: PaginationMeta;
}

export interface ApiErr {
  ok:      false;
  error:   string;
  code:    string;
  details?: Record<string, string[]>;
}

export type ApiResponse<T = unknown> = ApiOk<T> | ApiErr;

export interface PaginationMeta {
  page:       number;
  limit:      number;
  total:      number;
  totalPages: number;
  hasNext:    boolean;
  hasPrev:    boolean;
}

// ─── Project DTOs ──────────────────────────
export interface CreateProjectDto {
  title:           string;
  description:     string;
  category:        string;
  skills:          string[];
  budgetType:      "fixed" | "hourly";
  budgetMin:       number;
  budgetMax:       number;
  timeline:        string;
  experienceLevel: string;
  aiGenerated?:    boolean;
  aiPrompt?:       string;
}

export interface ProjectFilters {
  category?:        string;
  skills?:          string[];
  budgetMin?:       number;
  budgetMax?:       number;
  experienceLevel?: string;
  search?:          string;
  page?:            number;
  limit?:           number;
  sortBy?:          "newest" | "budget_high" | "budget_low" | "proposals";
}

// ─── Proposal DTOs ─────────────────────────
export interface CreateProposalDto {
  projectId:    string;
  coverLetter:  string;
  bidAmount:    number;
  bidType:      "fixed" | "hourly";
  deliveryDays: number;
  milestones?:  { title: string; description: string; amount: number; days: number }[];
}

// ─── AI DTOs ───────────────────────────────
export interface GenerateProjectDto {
  prompt:    string;
  category?: string;
}

export interface GeneratedProject {
  title:           string;
  description:     string;
  skills:          string[];
  budgetMin:       number;
  budgetMax:       number;
  timeline:        string;
  experienceLevel: string;
  milestones:      { title: string; description: string; percentage: number; days: number }[];
}

// ─── Message DTOs ──────────────────────────
export interface SendMessageDto {
  contractId:   string;
  content:      string;
  type?:        string;
  attachments?: string[];
}

// ─── Payment DTOs ──────────────────────────
export interface CreateEscrowDto {
  contractId:   string;
  milestoneId?: string;
  amount:       number;
  gateway:      "stcpay" | "fawry" | "stripe" | "vodafone";
}

// ─── Pagination ────────────────────────────
export interface PaginationMeta {
  page: number; limit: number; total: number;
  totalPages: number; hasNext: boolean; hasPrev: boolean;
}

export function getPagination(p?: number, l?: number) {
  const page  = Math.max(1, p  ?? 1);
  const limit = Math.min(50, Math.max(1, l ?? 20));
  return { skip: (page - 1) * limit, take: limit, page, limit };
}

export function buildMeta(total: number, page: number, limit: number): PaginationMeta {
  const totalPages = Math.ceil(total / limit);
  return { page, limit, total, totalPages, hasNext: page < totalPages, hasPrev: page > 1 };
}
