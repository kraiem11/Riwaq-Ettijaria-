// ╔══════════════════════════════════════════════════════════╗
// ║  رواق — Next.js Edge Middleware                         ║
// ║  Auth enforcement + Rate limiting + Security headers    ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

const ACCESS_SECRET = new TextEncoder().encode(process.env.JWT_ACCESS_SECRET ?? "");

// Routes that require authentication
const PROTECTED_PREFIXES = [
  "/api/projects",           // POST only — GET is public
  "/api/proposals",
  "/api/contracts",
  "/api/messages",
  "/api/payments",
  "/api/reviews",
  "/api/notifications",
  "/api/users/me",
  "/api/ai/match-freelancers",
  "/api/disputes",
];

// Routes completely public (no auth needed)
const PUBLIC_ROUTES = new Set([
  "/api/auth/register",
  "/api/auth/login",
  "/api/auth/refresh",
  "/api/health",
]);

export async function middleware(req: NextRequest): Promise<NextResponse> {
  const { pathname, method } = req.nextUrl;

  // ── Security headers ────────────────────────────────────
  const res = NextResponse.next();
  res.headers.set("X-Content-Type-Options",    "nosniff");
  res.headers.set("X-Frame-Options",           "DENY");
  res.headers.set("X-XSS-Protection",          "1; mode=block");
  res.headers.set("Referrer-Policy",           "strict-origin-when-cross-origin");
  res.headers.set("Permissions-Policy",        "camera=(), microphone=(), geolocation=()");

  // ── CORS for API routes ─────────────────────────────────
  if (pathname.startsWith("/api/")) {
    const origin = req.headers.get("origin") ?? "";
    const allowedOrigins = (process.env.ALLOWED_ORIGINS ?? "").split(",").map(s => s.trim());

    if (allowedOrigins.includes(origin) || process.env.NODE_ENV === "development") {
      res.headers.set("Access-Control-Allow-Origin",      origin);
      res.headers.set("Access-Control-Allow-Methods",     "GET,POST,PUT,PATCH,DELETE,OPTIONS");
      res.headers.set("Access-Control-Allow-Headers",     "Content-Type,Authorization");
      res.headers.set("Access-Control-Allow-Credentials", "true");
    }

    if (req.method === "OPTIONS") {
      return new NextResponse(null, { status: 204, headers: res.headers });
    }
  }

  // ── Skip auth for public routes ─────────────────────────
  if (PUBLIC_ROUTES.has(pathname)) return res;

  // ── GET /api/projects is public, everything else needs auth
  if (pathname === "/api/projects" && method === "GET") return res;
  if (pathname.match(/^\/api\/projects\/[^/]+$/) && method === "GET") return res;
  if (pathname === "/api/users" && method === "GET") return res;
  if (pathname.match(/^\/api\/users\/[^/]+$/) && method === "GET") return res;

  // ── Check if route needs protection ────────────────────
  const needsAuth = PROTECTED_PREFIXES.some(p => pathname.startsWith(p));
  if (!needsAuth) return res;

  // ── Extract & verify token ──────────────────────────────
  let token: string | undefined;

  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    token = authHeader.slice(7);
  } else {
    token = req.cookies.get("rw_access")?.value;
  }

  if (!token) {
    return NextResponse.json(
      { success: false, error: "غير مصرح — يرجى تسجيل الدخول" },
      { status: 401 }
    );
  }

  try {
    await jwtVerify(token, ACCESS_SECRET);
    return res;
  } catch {
    return NextResponse.json(
      { success: false, error: "انتهت صلاحية الجلسة — يرجى تسجيل الدخول مجدداً" },
      { status: 401 }
    );
  }
}

export const config = {
  matcher: ["/api/:path*"],
};
