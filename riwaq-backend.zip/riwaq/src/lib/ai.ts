// ─── lib/ai.ts ──────────────────────────────────────────────────────────────
// رواق AI Service Layer
// Wraps Anthropic Claude API for: project generation, smart matching,
// dispute arbitration, fake-review detection, and Arabic NLP

import Anthropic              from "@anthropic-ai/sdk";
import { prisma }             from "./prisma";
import type { GeneratedProject } from "@/types";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });
const MODEL     = "claude-opus-4-5";

// ─── § 1 — Project Generator ─────────────────────────────────────────────────

const PROJECT_GEN_SYSTEM = `أنت مساعد متخصص في صياغة مشاريع العمل الحر الاحترافية باللغة العربية لمنصة رواق.
مهمتك تحويل الأفكار البسيطة إلى مشاريع محددة وقابلة للتنفيذ.

القواعد الصارمة:
١. أجب دائماً بـ JSON نقي فقط — لا نص إضافي، لا backticks، لا مقدمات.
٢. الوصف يجب أن يكون بين 150-250 كلمة، احترافي ومحدد.
٣. المهارات: 4-6 مهارات تقنية دقيقة ومناسبة للمشروع.
٤. الميزانية: واقعية بالدولار الأمريكي بناءً على حجم المشروع.
٥. المراحل: 3-5 مراحل منطقية التسلسل.

الشكل المطلوب للإجابة:
{
  "title": "عنوان مشروع احترافي واضح",
  "description": "وصف شامل يشمل: الهدف الرئيسي، المتطلبات الوظيفية، معايير القبول",
  "skills": ["مهارة1", "مهارة2", "مهارة3", "مهارة4"],
  "budgetMin": 500,
  "budgetMax": 1500,
  "timeline": "2w",
  "experienceLevel": "MID",
  "milestones": [
    { "title": "اسم المرحلة", "description": "ما يُسلَّم", "percentage": 30, "days": 7 }
  ]
}
قيم timeline: "1w"|"2w"|"1m"|"3m+"
قيم experienceLevel: "ENTRY"|"MID"|"EXPERT"
مجموع percentages يجب أن يساوي 100.`;

export async function generateProject(prompt: string, category?: string): Promise<GeneratedProject> {
  const userMsg = `فكرة المشروع: ${prompt}${category ? `\nالفئة: ${category}` : ""}`;

  const response = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: 1500,
    system:     PROJECT_GEN_SYSTEM,
    messages:   [{ role: "user", content: userMsg }],
  });

  const raw  = response.content[0].type === "text" ? response.content[0].text : "";
  const clean = raw.replace(/```json|```/g, "").trim();

  try {
    const parsed = JSON.parse(clean) as GeneratedProject;

    // Normalise milestones percentages to sum exactly 100
    const total = parsed.milestones.reduce((s, m) => s + m.percentage, 0);
    if (total !== 100 && parsed.milestones.length > 0) {
      const factor = 100 / total;
      parsed.milestones = parsed.milestones.map(m => ({
        ...m,
        percentage: Math.round(m.percentage * factor),
      }));
    }

    return parsed;
  } catch {
    throw new Error("فشل في تحليل استجابة الذكاء الاصطناعي");
  }
}

// ─── § 2 — Smart Freelancer Matching ─────────────────────────────────────────

export async function matchFreelancers(projectId: string, limit = 5) {
  const project = await prisma.project.findUniqueOrThrow({
    where:  { id: projectId },
    select: { title: true, description: true, skills: true, budgetMin: true, budgetMax: true, experienceLevel: true, category: true },
  });

  // Fetch candidate pool: active freelancers with overlapping skills
  const candidates = await prisma.user.findMany({
    where: {
      role:     { in: ["FREELANCER", "BOTH"] },
      status:   "ACTIVE",
      skills:   { some: { skill: { in: project.skills } } },
      deletedAt: null,
    },
    include: { skills: true, _count: { select: { proposals: true, clientContracts: true } } },
    take:    50,
    orderBy: [{ avgRating: "desc" }, { completedJobs: "desc" }],
  });

  if (!candidates.length) return [];

  // Ask Claude to rank them
  const candidatesSummary = candidates.map(c => ({
    id:           c.id,
    skills:       c.skills.map(s => `${s.skill}(${s.level})`).join(", "),
    avgRating:    c.avgRating,
    completedJobs: c.completedJobs,
    successRate:  c.successRate,
    hourlyRate:   c.hourlyRate,
    country:      c.country,
  }));

  const matchSystem = `أنت محرك مطابقة ذكي لمنصة رواق للعمل الحر.
مهمتك: تحليل المشروع وترتيب المستقلين حسب مدى ملاءمتهم.
أجب بـ JSON نقي فقط — مصفوفة من أفضل ${limit} مستقلين بالترتيب.
الشكل: [{"id":"...","score":95,"reasons":["سبب1","سبب2"]}]
score: من 0-100. reasons: 2-3 أسباب محددة باللغة العربية.`;

  const matchMsg = `المشروع: ${project.title}
الفئة: ${project.category} | المهارات: ${project.skills.join(", ")}
الميزانية: $${project.budgetMin}-$${project.budgetMax} | الخبرة: ${project.experienceLevel}
الوصف: ${project.description.slice(0, 300)}

المستقلون المتاحون:
${JSON.stringify(candidatesSummary, null, 2)}

رتّب أفضل ${limit} مستقلين وفق درجة التوافق.`;

  const aiResp = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: 1000,
    system:     matchSystem,
    messages:   [{ role: "user", content: matchMsg }],
  });

  const rawMatch = aiResp.content[0].type === "text" ? aiResp.content[0].text : "[]";
  const rankings = JSON.parse(rawMatch.replace(/```json|```/g, "").trim()) as
    { id: string; score: number; reasons: string[] }[];

  // Merge AI rankings with DB data
  return rankings
    .map(r => {
      const c = candidates.find(x => x.id === r.id);
      if (!c) return null;
      return {
        freelancer: {
          id: c.id, displayName: c.displayName, username: c.username,
          avatarUrl: c.avatarUrl, avgRating: c.avgRating,
          completedJobs: c.completedJobs, successRate: c.successRate,
          hourlyRate: c.hourlyRate, country: c.country,
          skills: c.skills.map(s => s.skill),
        },
        matchScore:   r.score,
        matchReasons: r.reasons,
        estimatedBid: c.hourlyRate
          ? Number(c.hourlyRate) * 40  // rough fixed-bid estimate
          : Number(project.budgetMin) + (Number(project.budgetMax) - Number(project.budgetMin)) * 0.6,
      };
    })
    .filter(Boolean);
}

// ─── § 3 — Dispute Arbitration ───────────────────────────────────────────────

export async function runDisputeArbitration(disputeId: string) {
  const dispute = await prisma.dispute.findUniqueOrThrow({
    where:   { id: disputeId },
    include: {
      contract: {
        include: {
          project:     { select: { title: true, description: true } },
          milestones:  true,
          messages:    { orderBy: { createdAt: "asc" }, take: 100 },
        },
      },
    },
  });

  const system = `أنت حكّم عادل ومتجرد لفض نزاعات منصة رواق للعمل الحر.
مهمتك تحليل العقد والمحادثات والأدلة وإصدار حكم موثق.
أجب بـ JSON نقي:
{
  "recommendation": "CLIENT_WINS"|"FREELANCER_WINS"|"SPLIT",
  "confidence": 85,
  "analysis": "تحليل مفصل للحالة باللغة العربية (200-400 كلمة)",
  "clientRefundPercent": 0,
  "keyFindings": ["نقطة1","نقطة2","نقطة3"]
}
clientRefundPercent: نسبة المبلغ المُسترد للعميل (0-100).`;

  const content = `النزاع: ${dispute.reason}
الوصف: ${dispute.description}
المشروع: ${dispute.contract.project.title}
عدد المراحل المكتملة: ${dispute.contract.milestones.filter(m => m.status === "APPROVED").length} / ${dispute.contract.milestones.length}
عدد الرسائل: ${dispute.contract.messages.length}
أدلة مقدمة: ${JSON.stringify(dispute.evidence ?? [])}`;

  const aiResp = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: 1500,
    system,
    messages:   [{ role: "user", content }],
  });

  const raw    = aiResp.content[0].type === "text" ? aiResp.content[0].text : "{}";
  const result = JSON.parse(raw.replace(/```json|```/g, "").trim());

  // Persist AI ruling
  await prisma.dispute.update({
    where: { id: disputeId },
    data:  {
      aiAnalysis:       result.analysis,
      aiRecommendation: result.recommendation,
      aiConfidence:     result.confidence,
      aiRunAt:          new Date(),
      status:           "AI_RULED",
    },
  });

  return result;
}

// ─── § 4 — Fake Review Detection ─────────────────────────────────────────────

export async function analyseReviewAuthenticity(
  reviewText:   string,
  reviewerId:   string,
  revieweeId:   string,
): Promise<{ score: number; suspicious: boolean; reason: string }> {
  // Fetch reviewer history for context
  const [reviewer, priorReviews] = await Promise.all([
    prisma.user.findUnique({ where: { id: reviewerId }, select: { createdAt: true, completedJobs: true } }),
    prisma.review.findMany({
      where:   { reviewerId },
      select:  { overallRating: true, comment: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take:    10,
    }),
  ]);

  const system = `أنت نظام كشف التقييمات المزورة لمنصة رواق.
حلّل التقييم وأجب بـ JSON نقي:
{"score":90,"suspicious":false,"reason":"سبب موجز"}
score: مدى أصالة التقييم (0=مزور، 100=أصيل).
suspicious: true إذا score < 60.`;

  const msg = `التقييم: "${reviewText}"
تاريخ المراجع: مسجل منذ ${reviewer ? Math.floor((Date.now() - reviewer.createdAt.getTime()) / 86400000) : "?"} يوم | ${reviewer?.completedJobs ?? 0} وظيفة مكتملة
تقييماته السابقة: ${priorReviews.map(r => r.overallRating).join(", ") || "لا يوجد"}`;

  const aiResp = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: 300,
    system,
    messages:   [{ role: "user", content: msg }],
  });

  const raw = aiResp.content[0].type === "text" ? aiResp.content[0].text : "{}";
  return JSON.parse(raw.replace(/```json|```/g, "").trim());
}

// ─── § 5 — AI Chat Support ───────────────────────────────────────────────────

export async function chatSupport(
  messages:  { role: "user" | "assistant"; content: string }[],
  userId:    string,
): Promise<string> {
  const system = `أنت مساعد دعم ذكي لمنصة رواق للعمل الحر العربية.
أجب باللغة العربية بشكل ودي ومهني. لا تتجاوز 200 كلمة.
يمكنك المساعدة في: كيفية نشر المشاريع، تقديم العروض، نظام الدفع، فض النزاعات، والاستفسارات العامة.`;

  const aiResp = await anthropic.messages.create({
    model:      MODEL,
    max_tokens: 600,
    system,
    messages,
  });

  return aiResp.content[0].type === "text" ? aiResp.content[0].text : "عذراً، لم أتمكن من معالجة طلبك.";
}
