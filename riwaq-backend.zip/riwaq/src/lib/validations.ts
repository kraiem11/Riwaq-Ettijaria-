// ╔══════════════════════════════════════════════════════════╗
// ║  رواق — Zod Validation Schemas                          ║
// ╚══════════════════════════════════════════════════════════╝
import { z } from "zod";

// ── Auth ────────────────────────────────────────────────────
export const RegisterSchema = z.object({
  email:       z.string().email("بريد إلكتروني غير صالح"),
  password:    z.string()
    .min(8, "كلمة المرور يجب أن تكون 8 أحرف على الأقل")
    .regex(/[A-Z]/, "يجب أن تحتوي على حرف كبير")
    .regex(/[0-9]/, "يجب أن تحتوي على رقم"),
  username:    z.string()
    .min(3, "اسم المستخدم يجب أن يكون 3 أحرف على الأقل")
    .max(50, "اسم المستخدم يجب أن لا يتجاوز 50 حرفاً")
    .regex(/^[a-z0-9_-]+$/, "يجب أن يحتوي على أحرف إنجليزية صغيرة وأرقام وشرطات فقط"),
  displayName: z.string().min(2, "الاسم يجب أن يكون حرفين على الأقل").max(100),
  role:        z.enum(["CLIENT", "FREELANCER", "BOTH"]),
  phone:       z.string().regex(/^\+?[0-9]{8,15}$/, "رقم هاتف غير صالح").optional(),
  country:     z.string().length(2, "رمز الدولة يجب أن يكون حرفين").optional(),
});

export const LoginSchema = z.object({
  email:    z.string().email("بريد إلكتروني غير صالح"),
  password: z.string().min(1, "كلمة المرور مطلوبة"),
});

export const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1, "كلمة المرور الحالية مطلوبة"),
  newPassword:     z.string()
    .min(8, "كلمة المرور يجب أن تكون 8 أحرف على الأقل")
    .regex(/[A-Z]/, "يجب أن تحتوي على حرف كبير")
    .regex(/[0-9]/, "يجب أن تحتوي على رقم"),
});

// ── Profile ─────────────────────────────────────────────────
export const UpdateProfileSchema = z.object({
  displayName:  z.string().min(2).max(100).optional(),
  bio:          z.string().max(2000, "السيرة الذاتية يجب أن لا تتجاوز 2000 حرف").optional(),
  tagline:      z.string().max(200).optional(),
  hourlyRate:   z.number().positive("السعر يجب أن يكون موجباً").max(10000).optional(),
  availability: z.enum(["full_time", "part_time", "unavailable"]).optional(),
  country:      z.string().length(2).optional(),
  city:         z.string().max(100).optional(),
  timezone:     z.string().max(50).optional(),
  skills: z.array(z.object({
    skill:    z.string().min(1).max(100),
    level:    z.number().int().min(1).max(5),
    yearsExp: z.number().min(0).max(50).optional(),
  })).max(30, "الحد الأقصى 30 مهارة").optional(),
  languages: z.array(z.object({
    language:    z.string().min(2).max(10),
    proficiency: z.enum(["native", "fluent", "conversational", "basic"]),
  })).max(10).optional(),
});

// ── Projects ────────────────────────────────────────────────
export const CreateProjectSchema = z.object({
  title:           z.string().min(10, "العنوان يجب أن يكون 10 أحرف على الأقل").max(300),
  description:     z.string().min(50, "الوصف يجب أن يكون 50 حرفاً على الأقل").max(10000),
  category:        z.enum([
    "WEB_DEVELOPMENT","MOBILE_DEVELOPMENT","GRAPHIC_DESIGN","UI_UX_DESIGN",
    "CONTENT_WRITING","TRANSLATION","DIGITAL_MARKETING","SEO",
    "VIDEO_EDITING","MOTION_GRAPHICS","DATA_ANALYSIS","AI_ML",
    "PHOTOGRAPHY","VOICE_OVER","OTHER"
  ]),
  skills:          z.array(z.string().min(1).max(100)).min(1, "حدد مهارة واحدة على الأقل").max(15),
  budgetType:      z.enum(["fixed", "hourly"]),
  budgetMin:       z.number().positive("الميزانية الدنيا يجب أن تكون موجبة").max(1000000),
  budgetMax:       z.number().positive().max(1000000),
  timeline:        z.enum(["1w", "2w", "1m", "3m+"]),
  experienceLevel: z.enum(["ENTRY", "MID", "EXPERT"]).optional(),
  aiGenerated:     z.boolean().optional(),
  aiPrompt:        z.string().max(2000).optional(),
  deadline:        z.string().datetime().optional(),
}).refine(d => d.budgetMax >= d.budgetMin, {
  message: "الحد الأقصى للميزانية يجب أن يكون أكبر من الحد الأدنى",
  path:    ["budgetMax"],
});

export const ProjectFiltersSchema = z.object({
  page:            z.coerce.number().int().positive().default(1),
  limit:           z.coerce.number().int().positive().max(50).default(20),
  category:        z.string().optional(),
  budgetMin:       z.coerce.number().positive().optional(),
  budgetMax:       z.coerce.number().positive().optional(),
  experienceLevel: z.enum(["ENTRY", "MID", "EXPERT"]).optional(),
  timeline:        z.enum(["1w", "2w", "1m", "3m+"]).optional(),
  search:          z.string().max(200).optional(),
  sortBy:          z.enum(["createdAt", "budgetMax", "proposalCount"]).default("createdAt"),
  order:           z.enum(["asc", "desc"]).default("desc"),
});

// ── Proposals ───────────────────────────────────────────────
export const CreateProposalSchema = z.object({
  coverLetter:  z.string()
    .min(100, "الرسالة التقديمية يجب أن تكون 100 حرف على الأقل")
    .max(5000, "الرسالة التقديمية يجب أن لا تتجاوز 5000 حرف"),
  bidAmount:    z.number().positive("مبلغ العرض يجب أن يكون موجباً").max(1000000),
  bidType:      z.enum(["fixed", "hourly"]),
  deliveryDays: z.number().int().positive("مدة التسليم يجب أن تكون موجبة").max(365),
  milestones:   z.array(z.object({
    title:       z.string().min(3).max(300),
    description: z.string().min(10).max(1000),
    amount:      z.number().positive(),
    dueDate:     z.string().datetime().optional(),
  })).max(10).optional(),
  attachments:  z.array(z.string().url()).max(5).optional(),
});

// ── Messages ────────────────────────────────────────────────
export const SendMessageSchema = z.object({
  contractId:  z.string().uuid("معرّف العقد غير صالح"),
  content:     z.string().min(1, "الرسالة لا يمكن أن تكون فارغة").max(10000),
  type:        z.enum(["TEXT", "FILE"]).default("TEXT"),
  attachments: z.array(z.string().url()).max(5).optional(),
});

// ── Payments ────────────────────────────────────────────────
export const CreateEscrowSchema = z.object({
  contractId:      z.string().uuid(),
  amountFils:      z.number().int().positive("المبلغ يجب أن يكون موجباً"),
  gatewayProvider: z.enum(["stcpay", "fawry", "stripe", "vodafone"]),
  paymentMethod:   z.record(z.unknown()).optional(),
});

export const ReleaseEscrowSchema = z.object({
  escrowId:    z.string().uuid(),
  milestoneId: z.string().uuid(),
});

// ── Reviews ─────────────────────────────────────────────────
export const CreateReviewSchema = z.object({
  contractId:      z.string().uuid(),
  overallRating:   z.number().min(1).max(5),
  communication:   z.number().min(1).max(5),
  quality:         z.number().min(1).max(5),
  timeliness:      z.number().min(1).max(5),
  professionalism: z.number().min(1).max(5),
  comment:         z.string().max(3000).optional(),
});

// ── AI ──────────────────────────────────────────────────────
export const GenerateProjectSchema = z.object({
  prompt:   z.string().min(20, "الوصف يجب أن يكون 20 حرفاً على الأقل").max(2000),
  category: z.string().optional(),
});

export const MatchFreelancersSchema = z.object({
  projectId: z.string().uuid(),
  limit:     z.number().int().positive().max(20).default(5),
});

// ── Disputes ────────────────────────────────────────────────
export const OpenDisputeSchema = z.object({
  contractId:  z.string().uuid(),
  reason:      z.string().min(5).max(200),
  description: z.string().min(50).max(5000),
  evidence:    z.array(z.object({
    type:        z.enum(["file", "link", "text"]),
    url:         z.string().url().optional(),
    description: z.string().max(500),
  })).max(10).optional(),
});
