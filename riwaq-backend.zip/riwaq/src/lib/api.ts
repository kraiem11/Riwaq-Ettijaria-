// ╔══════════════════════════════════════════════════════════╗
// ║  رواق — API Response Utilities & Route Handler Wrapper  ║
// ╚══════════════════════════════════════════════════════════╝
import { NextRequest, NextResponse } from "next/server";
import { ZodError, ZodSchema } from "zod";
import { getAuthFromRequest } from "./auth";
import type { ApiResponse, JwtPayload, PaginationMeta } from "@/types";

// ── Typed JSON responses ────────────────────────────────────
export function ok<T>(data: T, meta?: PaginationMeta, status = 200): NextResponse {
  const body: ApiResponse<T> = { success: true, data, meta };
  return NextResponse.json(body, { status });
}

export function created<T>(data: T): NextResponse {
  return ok(data, undefined, 201);
}

export function noContent(): NextResponse {
  return new NextResponse(null, { status: 204 });
}

export function err(message: string, status = 400): NextResponse {
  const body: ApiResponse = { success: false, error: message };
  return NextResponse.json(body, { status });
}

export function validationErr(error: ZodError): NextResponse {
  const errors: Record<string, string[]> = {};
  error.errors.forEach(e => {
    const key = e.path.join(".");
    if (!errors[key]) errors[key] = [];
    errors[key].push(e.message);
  });
  const body: ApiResponse = { success: false, error: "بيانات غير صالحة", errors };
  return NextResponse.json(body, { status: 422 });
}

export function unauthorized(msg = "غير مصرح — يرجى تسجيل الدخول"): NextResponse {
  return err(msg, 401);
}

export function forbidden(msg = "ليس لديك صلاحية للقيام بهذا الإجراء"): NextResponse {
  return err(msg, 403);
}

export function notFound(resource = "المورد"): NextResponse {
  return err(`${resource} غير موجود`, 404);
}

export function serverError(e?: unknown): NextResponse {
  if (process.env.NODE_ENV === "development") console.error(e);
  return err("حدث خطأ داخلي في الخادم. يرجى المحاولة لاحقاً.", 500);
}

// ── Validate & parse request body ──────────────────────────
export async function parseBody<T>(
  req:    NextRequest,
  schema: ZodSchema<T>
): Promise<{ data: T; error: null } | { data: null; error: NextResponse }> {
  try {
    const body = await req.json();
    const data = schema.parse(body);
    return { data, error: null };
  } catch (e) {
    if (e instanceof ZodError) return { data: null, error: validationErr(e) };
    return { data: null, error: err("تعذّر تحليل جسم الطلب") };
  }
}

// ── Parse query params ──────────────────────────────────────
export function parseQuery<T>(
  req:    NextRequest,
  schema: ZodSchema<T>
): { data: T; error: null } | { data: null; error: NextResponse } {
  try {
    const params: Record<string, string> = {};
    req.nextUrl.searchParams.forEach((v, k) => { params[k] = v; });
    const data = schema.parse(params);
    return { data, error: null };
  } catch (e) {
    if (e instanceof ZodError) return { data: null, error: validationErr(e) };
    return { data: null, error: err("معاملات الاستعلام غير صالحة") };
  }
}

// ── Pagination builder ──────────────────────────────────────
export function buildPagination(
  page:  number,
  limit: number,
  total: number
): PaginationMeta {
  const totalPages = Math.ceil(total / limit);
  return {
    page, limit, total, totalPages,
    hasNext: page < totalPages,
    hasPrev: page > 1,
  };
}

export function paginationSkip(page: number, limit: number): number {
  return (page - 1) * limit;
}

// ── Protected route handler ─────────────────────────────────
type Handler = (req: NextRequest, ctx: { params: Record<string, string>; user: JwtPayload }) => Promise<NextResponse>;

export function withAuth(handler: Handler) {
  return async (req: NextRequest, ctx: { params: Record<string, string> }) => {
    const user = await getAuthFromRequest(req);
    if (!user) return unauthorized();
    try {
      return await handler(req, { ...ctx, user });
    } catch (e) {
      return serverError(e);
    }
  };
}

// ── Public route handler with error boundary ────────────────
type PublicHandler = (req: NextRequest, ctx: { params: Record<string, string> }) => Promise<NextResponse>;

export function withErrorBoundary(handler: PublicHandler): PublicHandler {
  return async (req, ctx) => {
    try {
      return await handler(req, ctx);
    } catch (e) {
      return serverError(e);
    }
  };
}

// ── Platform fee calculator ─────────────────────────────────
// 10% for contracts under $1000, 7% for $1000–$5000, 5% above
export function calculatePlatformFee(amountUSD: number): {
  platformFee: number;
  freelancerNet: number;
  feePercent: number;
} {
  const feePercent = amountUSD < 1000 ? 0.10 : amountUSD < 5000 ? 0.07 : 0.05;
  const platformFee  = parseFloat((amountUSD * feePercent).toFixed(2));
  const freelancerNet = parseFloat((amountUSD - platformFee).toFixed(2));
  return { platformFee, freelancerNet, feePercent };
}

// ── Convert fils to display amount ──────────────────────────
export const filsToAmount = (fils: bigint, decimals = 2): number =>
  parseFloat((Number(fils) / 100).toFixed(decimals));

export const amountToFils = (amount: number): bigint =>
  BigInt(Math.round(amount * 100));
