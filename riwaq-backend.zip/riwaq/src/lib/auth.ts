// ╔══════════════════════════════════════════════════════════╗
// ║  رواق — Authentication Library                          ║
// ║  JWT (jose) + bcryptjs + session management             ║
// ╚══════════════════════════════════════════════════════════╝
import { SignJWT, jwtVerify, type JWTPayload } from "jose";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { NextRequest } from "next/server";
import prisma from "./prisma";
import type { JwtPayload, TokenPair, UserRole, KycLevel } from "@/types";

// ── Constants ──────────────────────────────────────────────
const ACCESS_SECRET  = new TextEncoder().encode(process.env.JWT_ACCESS_SECRET!);
const REFRESH_SECRET = new TextEncoder().encode(process.env.JWT_REFRESH_SECRET!);
const ACCESS_TTL     = "15m";
const REFRESH_TTL    = "30d";
const BCRYPT_ROUNDS  = 12;

// ── Password helpers ────────────────────────────────────────
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, BCRYPT_ROUNDS);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// ── Token generation ────────────────────────────────────────
export async function generateTokens(payload: {
  sub:       string;
  email:     string;
  role:      UserRole;
  kycLevel:  KycLevel;
  sessionId: string;
}): Promise<TokenPair> {
  const accessToken = await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(ACCESS_TTL)
    .sign(ACCESS_SECRET);

  const refreshToken = await new SignJWT({ sub: payload.sub, sessionId: payload.sessionId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(REFRESH_TTL)
    .sign(REFRESH_SECRET);

  return { accessToken, refreshToken, expiresIn: 900 }; // 15min in seconds
}

// ── Token verification ──────────────────────────────────────
export async function verifyAccessToken(token: string): Promise<JwtPayload | null> {
  try {
    const { payload } = await jwtVerify(token, ACCESS_SECRET);
    return payload as unknown as JwtPayload;
  } catch {
    return null;
  }
}

export async function verifyRefreshToken(token: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, REFRESH_SECRET);
    return payload;
  } catch {
    return null;
  }
}

// ── Session management ──────────────────────────────────────
export async function createSession(
  userId:    string,
  ipAddress: string,
  userAgent: string
): Promise<string> {
  const sessionId = crypto.randomUUID();

  // Store a hash of the session ID (never the raw value)
  const tokenHash = await bcrypt.hash(sessionId, 8);

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 30);

  await prisma.userSession.create({
    data: { userId, tokenHash, ipAddress, userAgent, expiresAt },
  });

  return sessionId;
}

export async function revokeSession(tokenHash: string): Promise<void> {
  await prisma.userSession.deleteMany({ where: { tokenHash } });
}

export async function revokeAllUserSessions(userId: string): Promise<void> {
  await prisma.userSession.deleteMany({ where: { userId } });
}

// ── Cookie helpers ──────────────────────────────────────────
export function setAuthCookies(tokens: TokenPair): void {
  const cookieStore = cookies();
  const isProduction = process.env.NODE_ENV === "production";

  cookieStore.set("rw_access", tokens.accessToken, {
    httpOnly: true,
    secure:   isProduction,
    sameSite: "lax",
    maxAge:   tokens.expiresIn,
    path:     "/",
  });

  cookieStore.set("rw_refresh", tokens.refreshToken, {
    httpOnly: true,
    secure:   isProduction,
    sameSite: "lax",
    maxAge:   60 * 60 * 24 * 30, // 30 days
    path:     "/api/auth/refresh",
  });
}

export function clearAuthCookies(): void {
  const cookieStore = cookies();
  cookieStore.delete("rw_access");
  cookieStore.delete("rw_refresh");
}

// ── Request auth extraction ─────────────────────────────────
export async function getAuthFromRequest(
  req: NextRequest
): Promise<JwtPayload | null> {
  // 1. Try Authorization header (Bearer token)
  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    return verifyAccessToken(authHeader.slice(7));
  }

  // 2. Try cookie
  const cookie = req.cookies.get("rw_access");
  if (cookie?.value) {
    return verifyAccessToken(cookie.value);
  }

  return null;
}

// ── Permission guards ───────────────────────────────────────
export function canActAsClient(role: UserRole): boolean {
  return role === "CLIENT" || role === "BOTH" || role === "ADMIN";
}

export function canActAsFreelancer(role: UserRole): boolean {
  return role === "FREELANCER" || role === "BOTH" || role === "ADMIN";
}

export function isAdmin(role: UserRole): boolean {
  return role === "ADMIN";
}

// ── Notification helper (creates in-app notification) ───────
export async function createNotification(data: {
  userId:    string;
  type:      string;
  title:     string;
  body:      string;
  actionUrl?: string;
  meta?:     Record<string, unknown>;
}): Promise<void> {
  await prisma.notification.create({
    data: {
      userId:    data.userId,
      type:      data.type as any,
      title:     data.title,
      body:      data.body,
      actionUrl: data.actionUrl,
      meta:      data.meta,
    },
  });
}
