// ─── lib/response.ts ────────────────────────────────────────────────────────
// Typed API response builders + centralised error handler

import { NextResponse }  from "next/server";
import type { ApiOk, ApiErr, PaginationMeta } from "@/types";
import {
  UnauthorizedError, ForbiddenError,
  NotFoundError, ValidationError, ConflictError,
} from "./auth";

// ─── Success responses ───────────────────────────────────────────────────────

export function ok<T>(data: T, status = 200, meta?: PaginationMeta): NextResponse<ApiOk<T>> {
  return NextResponse.json({ ok: true, data, ...(meta && { meta }) }, { status });
}

export function created<T>(data: T): NextResponse<ApiOk<T>> {
  return ok(data, 201);
}

export function noContent(): NextResponse {
  return new NextResponse(null, { status: 204 });
}

// ─── Error responses ─────────────────────────────────────────────────────────

export function err(
  message: string,
  code:    string,
  status:  number,
  details?: Record<string, string[]>,
): NextResponse<ApiErr> {
  return NextResponse.json({ ok: false, error: message, code, ...(details && { details }) }, { status });
}

// ─── Centralised error handler ───────────────────────────────────────────────
// Wrap every route handler: handler(req) → catch → handleError(e)

export function handleError(error: unknown): NextResponse<ApiErr> {
  console.error("[API Error]", error);

  if (error instanceof UnauthorizedError) return err(error.message, error.code, 401);
  if (error instanceof ForbiddenError)    return err(error.message, error.code, 403);
  if (error instanceof NotFoundError)     return err(error.message, error.code, 404);
  if (error instanceof ConflictError)     return err(error.message, error.code, 409);
  if (error instanceof ValidationError)   return err(error.message, error.code, 422, error.details);

  // Prisma unique constraint violation
  if (isPrismaError(error, "P2002")) {
    return err("هذا المورد موجود بالفعل", "DUPLICATE", 409);
  }
  // Prisma record not found
  if (isPrismaError(error, "P2025")) {
    return err("المورد غير موجود", "NOT_FOUND", 404);
  }

  // Unknown
  return err("حدث خطأ داخلي في الخادم", "INTERNAL_ERROR", 500);
}

function isPrismaError(e: unknown, code: string): boolean {
  return typeof e === "object" && e !== null && (e as { code?: string }).code === code;
}

// ─── Route wrapper ───────────────────────────────────────────────────────────
// Usage: export const GET = route(async (req, ctx) => { ... })

type RouteHandler<TCtx = { params: Record<string, string> }> = (
  req:  Request,
  ctx?: TCtx,
) => Promise<NextResponse>;

export function route<TCtx = { params: Record<string, string> }>(
  handler: RouteHandler<TCtx>,
): RouteHandler<TCtx> {
  return async (req, ctx) => {
    try {
      return await handler(req, ctx);
    } catch (error) {
      return handleError(error);
    }
  };
}

// ─── Request parsing helpers ─────────────────────────────────────────────────

export async function parseBody<T>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    throw new ValidationError({ body: ["JSON غير صالح"] });
  }
}

export function parseSearchParams(url: string): URLSearchParams {
  return new URL(url).searchParams;
}

export function getIntParam(sp: URLSearchParams, key: string, def = 1): number {
  const v = parseInt(sp.get(key) ?? "");
  return isNaN(v) ? def : v;
}
