/**
 * components/home/FeaturesSection.tsx
 *
 * Showcases Riwaq's three core AI capabilities:
 *  1. مولّد المشاريع (AI Project Generator)
 *  2. المطابقة الذكية (Smart Matching)
 *  3. حكم الفضاء الذكي (AI Workspace Arbiter)
 *
 * Pure Server Component — no client state needed.
 */

import { Bot, Target, Scale, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

/* ── Feature data ─────────────────────────────────────────── */
const FEATURES = [
  {
    icon: Bot,
    iconBg:    'rgba(200,169,74,0.1)',
    iconBorder:'rgba(200,169,74,0.2)',
    iconColor: '#C8A94A',
    badgeText: 'جديد',
    badgeCls:  'badge-gold',
    title:     'مولّد المشاريع بالذكاء الاصطناعي',
    description:
      'صف فكرتك بجملة واحدة وسيكتب الذكاء الاصطناعي توصيفاً احترافياً كاملاً باللغة العربية — العنوان، والنطاق، والمخرجات المتوقعة، وكل التفاصيل.',
    cta:  { label: 'جرّب الآن', href: '/post-project' },
  },
  {
    icon: Target,
    iconBg:    'rgba(45,212,191,0.08)',
    iconBorder:'rgba(45,212,191,0.2)',
    iconColor: '#2DD4BF',
    badgeText: 'ذكي',
    badgeCls:  'badge-teal',
    title:     'المطابقة الذكية للمستقلين',
    description:
      'خوارزمية تحليل متقدمة تدرس مئات الإشارات — التخصص والتقييمات والمشاريع السابقة والإيقاع الزمني — لتقترح عليك أفضل ٥ مستقلين توافقاً مع مشروعك.',
    cta:  { label: 'اكتشف المستقلين', href: '/explore' },
  },
  {
    icon: Scale,
    iconBg:    'rgba(139,92,246,0.08)',
    iconBorder:'rgba(139,92,246,0.2)',
    iconColor: '#8B5CF6',
    badgeText: 'موثوق',
    badgeCls:  'badge-gold',
    title:     'حكم الفضاء الذكي',
    description:
      'نظام تحكيم مدعوم بالذكاء الاصطناعي يحلّل الأدلة والمراسلات والتسليمات لحل النزاعات بحياد تام وشفافية كاملة — دون الحاجة إلى تدخل بشري.',
    cta:  { label: 'تعرّف أكثر', href: '/how-it-works#arbiter' },
  },
] as const;

/* ── Component ────────────────────────────────────────────── */
export default function FeaturesSection() {
  return (
    <section
      className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20"
      aria-labelledby="features-heading"
    >
      {/* Section header */}
      <header className="text-center mb-12">
        <p className="section-label mb-3">قدرات الذكاء الاصطناعي</p>
        <h2
          id="features-heading"
          className="text-3xl sm:text-4xl font-black tracking-tight"
          style={{ color: '#F5EFE0' }}
        >
          كل ما تحتاجه في منصة واحدة
        </h2>
        <p className="mt-3 text-sm max-w-md mx-auto leading-relaxed" style={{ color: '#8C95A8' }}>
          لا تبدأ مشروعك وحدك — استعن بأدوات الذكاء الاصطناعي في كل مرحلة
        </p>
      </header>

      {/* Feature cards grid */}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map(({ icon: Icon, iconBg, iconBorder, iconColor, badgeText, badgeCls, title, description, cta }) => (
          <article
            key={title}
            className="riwaq-card group flex flex-col gap-4 transition-all duration-300 hover:-translate-y-1"
            style={{ '--hover-border': 'rgba(200,169,74,0.3)' } as React.CSSProperties}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.borderColor = 'rgba(200,169,74,0.3)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.borderColor = 'rgba(200,169,74,0.12)';
            }}
          >
            {/* Icon */}
            <div
              className="flex h-11 w-11 items-center justify-center rounded-xl shrink-0"
              style={{ background: iconBg, border: `1px solid ${iconBorder}` }}
              aria-hidden="true"
            >
              <Icon size={20} style={{ color: iconColor }} />
            </div>

            {/* Title + badge */}
            <div className="flex items-start gap-3">
              <h3 className="flex-1 text-[15px] font-bold leading-snug" style={{ color: '#F5EFE0' }}>
                {title}
              </h3>
              <span className={`${badgeCls} shrink-0 text-[10px] px-2 py-0.5`}>
                {badgeText}
              </span>
            </div>

            {/* Description */}
            <p className="text-[13px] leading-[1.75]" style={{ color: '#6B7A94' }}>
              {description}
            </p>

            {/* CTA link */}
            <Link
              href={cta.href}
              className="mt-auto flex items-center gap-1.5 text-[13px] font-medium transition-all duration-200"
              style={{ color: iconColor }}
              aria-label={`${cta.label} — ${title}`}
            >
              {cta.label}
              <ArrowLeft
                size={13}
                aria-hidden="true"
                className="transition-transform group-hover:-translate-x-1"
              />
            </Link>
          </article>
        ))}
      </div>

      {/* Trusted-by row */}
      <div
        className="mt-14 rounded-2xl p-6 flex flex-wrap items-center justify-between gap-6"
        style={{ background: 'rgba(200,169,74,0.04)', border: '1px solid rgba(200,169,74,0.1)' }}
      >
        <p className="text-sm font-medium" style={{ color: '#8C95A8' }}>
          موثوق لدى شركات رائدة في المنطقة
        </p>
        {/* TODO: replace with actual client logos */}
        <div className="flex flex-wrap gap-6">
          {['STC', 'Noon', 'Aramco Digital', 'Souq.com', 'Careem'].map(brand => (
            <span
              key={brand}
              className="text-sm font-semibold tracking-wide"
              style={{ color: 'rgba(200,169,74,0.35)' }}
            >
              {brand}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
