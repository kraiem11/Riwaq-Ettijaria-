/**
 * components/home/HeroSection.tsx
 *
 * High-converting hero for Riwaq homepage:
 *  - Animated headline with gradient brand words
 *  - Interactive search bar (client component for state)
 *  - Category quick-filter pills
 *  - Social-proof stat counters
 *  - Geometric Islamic-inspired grid background
 */

'use client';

import { useState } from 'react';
import { Search, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

/* ── Static data ──────────────────────────────────────────── */
const CATEGORIES = [
  'تطوير ويب',
  'تصميم جرافيك',
  'تسويق رقمي',
  'برمجة تطبيقات',
  'كتابة محتوى',
  'ترجمة',
  'فيديو وموشن',
  'صوت وموسيقى',
] as const;

const STATS = [
  { value: '٢٠٬٠٠٠+', label: 'مستقل موثّق'   },
  { value: '٨٥٠٠+',   label: 'مشروع مكتمل'   },
  { value: '٩٤٪',     label: 'رضا العملاء'    },
] as const;

/* ── Component ────────────────────────────────────────────── */
export default function HeroSection() {
  const [query, setQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: route to /explore?q=<query> and trigger server-side search
    if (query.trim()) {
      window.location.href = `/explore?q=${encodeURIComponent(query.trim())}`;
    }
  };

  return (
    <section
      className="relative overflow-hidden px-4 py-24 text-center"
      aria-labelledby="hero-heading"
    >
      {/* Geometric grid background (decorative) */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `
            repeating-linear-gradient(0deg,transparent,transparent 40px,rgba(200,169,74,.7) 40px,rgba(200,169,74,.7) 41px),
            repeating-linear-gradient(90deg,transparent,transparent 40px,rgba(200,169,74,.7) 40px,rgba(200,169,74,.7) 41px)
          `,
        }}
      />

      {/* Radial glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-0 -translate-x-1/2 h-[500px] w-[700px] rounded-full"
        style={{ background: 'radial-gradient(circle, rgba(200,169,74,.07) 0%, transparent 70%)' }}
      />

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-2xl">

        {/* Category badge */}
        <div className="mb-6 flex justify-center">
          <span className="badge-gold text-[13px] flex items-center gap-1.5 animate-fade-up">
            <span aria-hidden="true">✦</span>
            منصة العمل الحر بالذكاء الاصطناعي رقم ١ في العالم العربي
          </span>
        </div>

        {/* Headline */}
        <h1
          id="hero-heading"
          className="text-4xl sm:text-5xl font-black leading-[1.2] tracking-tight mb-5"
          style={{ color: '#F5EFE0', animationDelay: '0.1s' }}
        >
          أطلق مشاريعك بقوة{' '}
          <span
            style={{
              background: 'linear-gradient(135deg,#C8A94A,#F0C96A)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            الذكاء الاصطناعي
          </span>
        </h1>

        {/* Sub-headline */}
        <p className="text-base sm:text-lg leading-relaxed mb-8 max-w-lg mx-auto" style={{ color: '#8C95A8' }}>
          رواق يربط أصحاب العمل بأفضل المستقلين العرب، مع أدوات ذكاء اصطناعي تُسرّع كل خطوة
          من خطوات المشروع — من الصياغة حتى التسليم.
        </p>

        {/* ── Search bar ────────────────────────────────────── */}
        <form
          onSubmit={handleSearch}
          className="mx-auto mb-6 flex max-w-xl items-center gap-3 rounded-xl p-1.5 pl-4"
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(200,169,74,0.22)',
            backdropFilter: 'blur(10px)',
          }}
          role="search"
          aria-label="البحث في المشاريع"
        >
          <Search size={18} className="shrink-0" style={{ color: '#C8A94A' }} aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="ابحث عن مشروع أو مهارة أو مستقل..."
            className="min-w-0 flex-1 bg-transparent text-sm outline-none py-2"
            style={{ color: '#F0EDE8', fontFamily: 'Tajawal, sans-serif' }}
            aria-label="مصطلح البحث"
          />
          <button type="submit" className="btn-primary shrink-0 text-sm py-2 px-4">
            ابحث الآن
          </button>
        </form>

        {/* ── Category pills ─────────────────────────────────── */}
        <div
          className="mb-10 flex flex-wrap justify-center gap-2"
          role="list"
          aria-label="تصفح حسب التصنيف"
        >
          {CATEGORIES.map(cat => (
            <Link
              key={cat}
              href={`/explore?category=${encodeURIComponent(cat)}`}
              role="listitem"
              className="text-xs rounded-full px-4 py-1.5 transition-all duration-200"
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.08)',
                color: '#9BA8BC',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.borderColor = 'rgba(200,169,74,0.4)';
                (e.currentTarget as HTMLElement).style.color = '#C8A94A';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.borderColor = 'rgba(255,255,255,0.08)';
                (e.currentTarget as HTMLElement).style.color = '#9BA8BC';
              }}
            >
              {cat}
            </Link>
          ))}
        </div>

        {/* ── Stats ──────────────────────────────────────────── */}
        <dl className="mx-auto grid max-w-sm grid-cols-3 gap-4">
          {STATS.map(({ value, label }) => (
            <div key={label} className="text-center">
              <dt className="sr-only">{label}</dt>
              <dd>
                <span className="block text-2xl font-black" style={{ color: '#C8A94A' }}>
                  {value}
                </span>
                <span className="mt-0.5 block text-xs" style={{ color: '#4A5568' }}>
                  {label}
                </span>
              </dd>
            </div>
          ))}
        </dl>

        {/* CTA pair */}
        <div className="mt-8 flex justify-center gap-3 flex-wrap">
          <Link href="/post-project" className="btn-primary gap-2">
            <span>انشر مشروعك الآن</span>
            <span aria-hidden="true">✦</span>
          </Link>
          <Link href="/explore" className="btn-outline gap-2">
            <span>تصفّح المستقلين</span>
            <ArrowLeft size={15} aria-hidden="true" />
          </Link>
        </div>

      </div>
    </section>
  );
}
