/**
 * components/post-project/MultiStepForm.tsx
 *
 * 4-step project posting form with:
 *  Step 1 — Project title & category
 *  Step 2 — Description (+ AI generation button)
 *  Step 3 — Budget, duration & experience level
 *  Step 4 — Required skills & final review
 *
 * AI integration:
 *  - Streams description from POST /api/ai/generate-description
 *  - Shows typing cursor during generation
 *
 * State management:
 *  - Local useState (suitable for this scope)
 *  - TODO: replace with React Hook Form + Zod for production validation
 *  - TODO: replace form submission with a server action / tRPC mutation
 */

'use client';

import { useState, useRef } from 'react';
import {
  Sparkles, ChevronLeft, ChevronRight,
  CheckCircle, Loader2, Lightbulb,
} from 'lucide-react';
import clsx from 'clsx';

/* ── Types ────────────────────────────────────────────────── */
interface FormState {
  title:         string;
  category:      string;
  description:   string;
  budget:        string;
  budgetType:    'fixed' | 'hourly';
  duration:      string;
  experienceLevel: 'beginner' | 'intermediate' | 'expert';
  skills:        string[];
}

/* ── Static data ──────────────────────────────────────────── */
const CATEGORIES = [
  'تطوير ويب', 'تطوير تطبيقات موبايل', 'تصميم جرافيك', 'تصميم UI/UX',
  'تسويق رقمي', 'كتابة محتوى', 'ترجمة', 'تحليل بيانات',
  'أمن معلومات', 'ذكاء اصطناعي / تعلم الآلة',
] as const;

const DURATION_OPTIONS = [
  'أقل من أسبوع', '١–٢ أسبوع', '٣–٤ أسبوع', '١–٣ أشهر', 'أكثر من ٣ أشهر',
] as const;

const EXPERIENCE_LEVELS = [
  { value: 'beginner',     label: 'مبتدئ',  desc: 'مناسب للمهام البسيطة وذات الميزانية المنخفضة'  },
  { value: 'intermediate', label: 'متوسط',  desc: 'خبرة ٢–٥ سنوات في المجال'                     },
  { value: 'expert',       label: 'خبير',   desc: 'يتطلب إتقاناً عالياً ومشاريع مماثلة موثّقة'  },
] as const;

const ALL_SKILLS = [
  'React', 'Next.js', 'Vue.js', 'Node.js', 'Python', 'TypeScript',
  'PHP', 'Laravel', 'Flutter', 'React Native', 'Swift', 'Kotlin',
  'Figma', 'Adobe XD', 'Illustrator', 'Photoshop',
  'SEO', 'Google Ads', 'Social Media', 'Content Writing',
  'SQL', 'MongoDB', 'PostgreSQL', 'Firebase',
  'AWS', 'Docker', 'DevOps',
] as const;

const STEPS = ['التصنيف', 'التوصيف', 'الميزانية', 'المراجعة'] as const;

/* ── Initial state ────────────────────────────────────────── */
const INITIAL_FORM: FormState = {
  title: '', category: '', description: '',
  budget: '', budgetType: 'fixed', duration: '',
  experienceLevel: 'intermediate', skills: [],
};

/* ── Main component ───────────────────────────────────────── */
export default function MultiStepForm() {
  const [step,       setStep]       = useState(1);
  const [form,       setForm]       = useState<FormState>(INITIAL_FORM);
  const [aiLoading,  setAiLoading]  = useState(false);
  const [aiGenerated,setAiGenerated]= useState(false);
  const [submitted,  setSubmitted]  = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  /* ── Field updater ──────────────────────────────────────── */
  const update = <K extends keyof FormState>(key: K, val: FormState[K]) =>
    setForm(prev => ({ ...prev, [key]: val }));

  /* ── Skill toggle ───────────────────────────────────────── */
  const toggleSkill = (skill: string) =>
    update('skills',
      form.skills.includes(skill)
        ? form.skills.filter(s => s !== skill)
        : [...form.skills, skill]
    );

  /* ── Step validation ────────────────────────────────────── */
  const canAdvance = () => {
    if (step === 1) return form.title.trim().length >= 5 && !!form.category;
    if (step === 2) return form.description.trim().length >= 20;
    if (step === 3) return !!form.budget && !!form.duration;
    return true;
  };

  /* ── AI Description generator (streaming) ──────────────── */
  const generateDescription = async () => {
    if (!form.title || !form.category) return;

    // Abort any in-flight request
    abortRef.current?.abort();
    abortRef.current = new AbortController();

    setAiLoading(true);
    setAiGenerated(false);
    update('description', '');

    try {
      const res = await fetch('/api/ai/generate-description', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: form.title, category: form.category }),
        signal: abortRef.current.signal,
      });

      if (!res.ok || !res.body) throw new Error('فشل الاتصال بالذكاء الاصطناعي');

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        accumulated += decoder.decode(value, { stream: true });
        update('description', accumulated);
      }

      setAiGenerated(true);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        update('description', 'تعذّر الاتصال بالذكاء الاصطناعي. يرجى المحاولة مجدداً.');
      }
    } finally {
      setAiLoading(false);
    }
  };

  /* ── Form submission ────────────────────────────────────── */
  const handleSubmit = async () => {
    /*
     * TODO: Replace with a Next.js Server Action or tRPC mutation.
     * Example:
     *   const project = await createProject(form);
     *   router.push(`/projects/${project.id}/success`);
     */
    setSubmitted(true);
  };

  /* ── Success screen ─────────────────────────────────────── */
  if (submitted) {
    return (
      <div className="riwaq-card text-center py-12 max-w-lg mx-auto">
        <div className="flex justify-center mb-5">
          <CheckCircle size={48} style={{ color: '#2DD4BF' }} />
        </div>
        <h2 className="text-xl font-bold mb-3" style={{ color: '#F5EFE0' }}>
          🎉 تم نشر مشروعك بنجاح!
        </h2>
        <p className="text-sm leading-relaxed mb-6" style={{ color: '#8C95A8' }}>
          سيقوم الذكاء الاصطناعي بمراجعة مشروعك ومطابقته مع أفضل المستقلين خلال دقائق.
          ستتلقى إشعاراً فور وصول العروض.
        </p>
        <div className="flex gap-3 justify-center flex-wrap">
          <button className="btn-primary" onClick={() => { setSubmitted(false); setStep(1); setForm(INITIAL_FORM); }}>
            نشر مشروع جديد
          </button>
          <a href="/dashboard" className="btn-ghost">لوحة التحكم</a>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">

      {/* ── Step progress ─────────────────────────────────── */}
      <div className="mb-8" role="navigation" aria-label="خطوات نشر المشروع">
        <div className="flex items-center">
          {STEPS.map((label, idx) => {
            const num = idx + 1;
            const state = num < step ? 'done' : num === step ? 'active' : 'idle';
            return (
              <div key={label} className="flex flex-1 items-center">
                {/* Dot */}
                <div className="flex flex-col items-center gap-1.5">
                  <div
                    className={clsx('flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold transition-all shrink-0', {
                      'text-[#060C18]': state === 'active',
                      'text-[#2DD4BF]': state === 'done',
                      'text-[#4A5568]': state === 'idle',
                    })}
                    style={{
                      background:
                        state === 'active' ? 'linear-gradient(135deg,#C8A94A,#F0C96A)' :
                        state === 'done'   ? 'rgba(45,212,191,0.15)' :
                        'rgba(255,255,255,0.06)',
                      border:
                        state === 'done' ? '1px solid #2DD4BF' :
                        state === 'idle' ? '1px solid rgba(255,255,255,0.1)' : 'none',
                    }}
                    aria-current={state === 'active' ? 'step' : undefined}
                  >
                    {state === 'done' ? '✓' : num}
                  </div>
                  <span
                    className="text-[11px] font-medium whitespace-nowrap"
                    style={{ color: state === 'active' ? '#C8A94A' : '#4A5568' }}
                  >
                    {label}
                  </span>
                </div>
                {/* Connector */}
                {idx < STEPS.length - 1 && (
                  <div
                    className="flex-1 h-px mx-2 mb-4 transition-all duration-500"
                    style={{ background: num < step ? 'rgba(45,212,191,0.4)' : 'rgba(255,255,255,0.06)' }}
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* Progress bar */}
        <div className="mt-4 h-1 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${((step - 1) / (STEPS.length - 1)) * 100}%`,
              background: 'linear-gradient(90deg,#C8A94A,#2DD4BF)',
            }}
          />
        </div>
      </div>

      {/* ══ STEP 1: Title & Category ══════════════════════════ */}
      {step === 1 && (
        <div className="riwaq-card space-y-5" role="form" aria-label="الخطوة ١: عنوان المشروع والتصنيف">
          <div>
            <h2 className="text-lg font-bold mb-1" style={{ color: '#F5EFE0' }}>عنوان المشروع والتصنيف</h2>
            <p className="text-sm" style={{ color: '#6B7A94' }}>أخبرنا بفكرتك باختصار</p>
          </div>

          {/* Title */}
          <div>
            <label htmlFor="title" className="block text-sm font-medium mb-2" style={{ color: '#8C95A8' }}>
              عنوان المشروع <span className="text-red-400" aria-hidden="true">*</span>
            </label>
            <input
              id="title"
              type="text"
              maxLength={100}
              className="riwaq-input"
              placeholder="مثال: تطوير متجر إلكتروني متكامل باستخدام Next.js"
              value={form.title}
              onChange={e => update('title', e.target.value)}
              aria-required="true"
            />
            <p className="mt-1.5 text-xs text-end" style={{ color: '#4A5568' }}>
              {form.title.length} / 100
            </p>
          </div>

          {/* Category */}
          <div>
            <label htmlFor="category" className="block text-sm font-medium mb-2" style={{ color: '#8C95A8' }}>
              التصنيف <span className="text-red-400" aria-hidden="true">*</span>
            </label>
            <select
              id="category"
              className="riwaq-input"
              value={form.category}
              onChange={e => update('category', e.target.value)}
              aria-required="true"
              style={{ background: 'rgba(255,255,255,0.04)' }}
            >
              <option value="" disabled>اختر التصنيف المناسب لمشروعك</option>
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat} style={{ background: '#0D1525' }}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Advance */}
          <div className="flex justify-start pt-2">
            <button
              className={clsx('btn-primary gap-2', !canAdvance() && 'opacity-40 cursor-not-allowed')}
              onClick={() => canAdvance() && setStep(2)}
              disabled={!canAdvance()}
            >
              <span>التالي</span>
              <ChevronLeft size={16} aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      {/* ══ STEP 2: Description + AI button ══════════════════ */}
      {step === 2 && (
        <div className="riwaq-card space-y-5" role="form" aria-label="الخطوة ٢: توصيف المشروع">
          <div>
            <h2 className="text-lg font-bold mb-1" style={{ color: '#F5EFE0' }}>توصيف المشروع</h2>
            <p className="text-sm" style={{ color: '#6B7A94' }}>كلما كان التوصيف أوضح، زادت جودة العروض المستلمة</p>
          </div>

          {/* ── AI Generate button ─────────────────────────── */}
          <button
            type="button"
            onClick={generateDescription}
            disabled={aiLoading}
            className="w-full rounded-xl p-4 flex items-center gap-3 text-right transition-all duration-200"
            style={{
              background: aiLoading
                ? 'rgba(200,169,74,0.06)'
                : 'linear-gradient(135deg, rgba(200,169,74,0.1), rgba(45,212,191,0.06))',
              border: '1px dashed rgba(200,169,74,0.4)',
              cursor: aiLoading ? 'default' : 'pointer',
            }}
            aria-label="صياغة المشروع بالذكاء الاصطناعي"
          >
            <div
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
              style={{ background: 'rgba(200,169,74,0.1)', border: '1px solid rgba(200,169,74,0.2)' }}
              aria-hidden="true"
            >
              {aiLoading
                ? <Loader2 size={18} style={{ color: '#C8A94A' }} className="animate-spin" />
                : <Sparkles size={18} style={{ color: '#C8A94A' }} />
              }
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold" style={{ color: '#C8A94A' }}>
                {aiLoading ? 'جارٍ صياغة المشروع...' : 'صياغة المشروع بالذكاء الاصطناعي ✦'}
              </p>
              <p className="text-xs mt-0.5" style={{ color: '#5A6478' }}>
                {aiLoading
                  ? 'يكتب الذكاء الاصطناعي توصيفاً احترافياً...'
                  : 'اضغط لتوليد توصيف كامل ومحترف تلقائياً من العنوان والتصنيف'}
              </p>
            </div>
            {aiGenerated && (
              <span className="badge-teal shrink-0 text-[11px]">تم ✓</span>
            )}
          </button>

          {/* Description textarea */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="description" className="text-sm font-medium" style={{ color: '#8C95A8' }}>
                وصف المشروع <span className="text-red-400" aria-hidden="true">*</span>
              </label>
              {aiGenerated && (
                <span className="text-xs flex items-center gap-1" style={{ color: '#2DD4BF' }}>
                  <Sparkles size={11} aria-hidden="true" />
                  مُولَّد بالذكاء الاصطناعي
                </span>
              )}
            </div>
            <div className="relative">
              <textarea
                id="description"
                className="riwaq-input"
                rows={8}
                style={{ resize: 'vertical', minHeight: 180 }}
                placeholder="اكتب توصيفاً تفصيلياً... أو اضغط على الزر أعلاه ليكتبه الذكاء الاصطناعي."
                value={form.description}
                onChange={e => update('description', e.target.value)}
                aria-required="true"
              />
              {/* Blinking cursor during AI generation */}
              {aiLoading && (
                <span
                  aria-hidden="true"
                  className="absolute"
                  style={{
                    bottom: 14, left: 14,
                    display: 'inline-block', width: 8, height: 16,
                    background: '#C8A94A', borderRadius: 2,
                    animation: 'blink 0.7s infinite',
                  }}
                />
              )}
            </div>
          </div>

          {/* AI tip */}
          <div className="ai-hint flex gap-3 items-start">
            <Lightbulb size={16} style={{ color: '#2DD4BF', flexShrink: 0, marginTop: 2 }} aria-hidden="true" />
            <p className="text-xs leading-relaxed">
              <strong style={{ color: '#2DD4BF' }}>نصيحة:</strong>{' '}
              المشاريع ذات التوصيف الواضح تحصل على عروض أسرع بنسبة ٦٠٪ — اذكر الهدف، المخرجات، والمدة المتوقعة.
            </p>
          </div>

          {/* Navigation */}
          <div className="flex justify-between pt-2">
            <button className="btn-ghost gap-2" onClick={() => setStep(1)}>
              <ChevronRight size={16} aria-hidden="true" />
              <span>السابق</span>
            </button>
            <button
              className={clsx('btn-primary gap-2', !canAdvance() && 'opacity-40 cursor-not-allowed')}
              onClick={() => canAdvance() && setStep(3)}
              disabled={!canAdvance()}
            >
              <span>التالي</span>
              <ChevronLeft size={16} aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      {/* ══ STEP 3: Budget, Duration, Level ══════════════════ */}
      {step === 3 && (
        <div className="riwaq-card space-y-5" role="form" aria-label="الخطوة ٣: الميزانية والمدة">
          <div>
            <h2 className="text-lg font-bold mb-1" style={{ color: '#F5EFE0' }}>الميزانية والمدة الزمنية</h2>
            <p className="text-sm" style={{ color: '#6B7A94' }}>حدّد ميزانيتك لتستقطب المستقلين الأنسب</p>
          </div>

          {/* Budget type toggle */}
          <div>
            <label className="block text-sm font-medium mb-3" style={{ color: '#8C95A8' }}>نوع الميزانية</label>
            <div className="flex gap-2">
              {(['fixed', 'hourly'] as const).map(type => (
                <button
                  key={type}
                  type="button"
                  onClick={() => update('budgetType', type)}
                  className={clsx('flex-1 py-2 rounded-lg text-sm font-medium transition-all border', {
                    'border-transparent text-[#060C18]': form.budgetType === type,
                  })}
                  style={{
                    background: form.budgetType === type
                      ? 'linear-gradient(135deg,#C8A94A,#F0C96A)'
                      : 'rgba(255,255,255,0.04)',
                    borderColor: form.budgetType !== type ? 'rgba(255,255,255,0.08)' : 'transparent',
                    color: form.budgetType !== type ? '#8C95A8' : undefined,
                    fontFamily: 'Tajawal, sans-serif',
                  }}
                  aria-pressed={form.budgetType === type}
                >
                  {type === 'fixed' ? 'سعر ثابت' : 'بالساعة'}
                </button>
              ))}
            </div>
          </div>

          {/* Budget + Duration row */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="budget" className="block text-sm font-medium mb-2" style={{ color: '#8C95A8' }}>
                الميزانية (ر.س) <span className="text-red-400" aria-hidden="true">*</span>
              </label>
              <input
                id="budget"
                type="number"
                min="0"
                className="riwaq-input"
                placeholder={form.budgetType === 'hourly' ? 'سعر الساعة' : 'الميزانية الكلية'}
                value={form.budget}
                onChange={e => update('budget', e.target.value)}
                aria-required="true"
              />
            </div>
            <div>
              <label htmlFor="duration" className="block text-sm font-medium mb-2" style={{ color: '#8C95A8' }}>
                المدة الزمنية <span className="text-red-400" aria-hidden="true">*</span>
              </label>
              <select
                id="duration"
                className="riwaq-input"
                value={form.duration}
                onChange={e => update('duration', e.target.value)}
                style={{ background: 'rgba(255,255,255,0.04)' }}
              >
                <option value="" disabled>اختر المدة</option>
                {DURATION_OPTIONS.map(d => (
                  <option key={d} value={d} style={{ background: '#0D1525' }}>{d}</option>
                ))}
              </select>
            </div>
          </div>

          {/* AI budget suggestion */}
          {form.budget && Number(form.budget) > 0 && (
            <div
              className="rounded-lg p-3 text-xs"
              style={{ background: 'rgba(200,169,74,0.06)', border: '1px solid rgba(200,169,74,0.15)' }}
            >
              <span style={{ color: '#C8A94A' }}>💡 توصية الذكاء الاصطناعي: </span>
              <span style={{ color: '#8C95A8' }}>
                المشاريع المماثلة في تصنيف "{form.category}" تتراوح بين{' '}
                <strong style={{ color: '#C8A94A' }}>
                  {Math.round(Number(form.budget) * 0.8).toLocaleString('ar')} –{' '}
                  {Math.round(Number(form.budget) * 1.5).toLocaleString('ar')} ر.س
                </strong>
                . ميزانيتك تنافسية.
              </span>
            </div>
          )}

          {/* Experience level */}
          <div>
            <label className="block text-sm font-medium mb-3" style={{ color: '#8C95A8' }}>مستوى الخبرة المطلوب</label>
            <div className="space-y-2">
              {EXPERIENCE_LEVELS.map(lvl => (
                <button
                  key={lvl.value}
                  type="button"
                  onClick={() => update('experienceLevel', lvl.value)}
                  className="w-full text-right flex items-start gap-3 rounded-lg p-3 transition-all border"
                  style={{
                    background: form.experienceLevel === lvl.value ? 'rgba(200,169,74,0.06)' : 'rgba(255,255,255,0.02)',
                    borderColor: form.experienceLevel === lvl.value ? 'rgba(200,169,74,0.3)' : 'rgba(255,255,255,0.06)',
                    fontFamily: 'Tajawal, sans-serif',
                  }}
                  aria-pressed={form.experienceLevel === lvl.value}
                >
                  <div
                    className="mt-0.5 h-4 w-4 shrink-0 rounded-full border-2 flex items-center justify-center"
                    style={{
                      borderColor: form.experienceLevel === lvl.value ? '#C8A94A' : '#4A5568',
                    }}
                    aria-hidden="true"
                  >
                    {form.experienceLevel === lvl.value && (
                      <div className="h-2 w-2 rounded-full" style={{ background: '#C8A94A' }} />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: '#F0EDE8' }}>{lvl.label}</p>
                    <p className="text-xs mt-0.5" style={{ color: '#6B7A94' }}>{lvl.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-between pt-2">
            <button className="btn-ghost gap-2" onClick={() => setStep(2)}>
              <ChevronRight size={16} aria-hidden="true" /><span>السابق</span>
            </button>
            <button
              className={clsx('btn-primary gap-2', !canAdvance() && 'opacity-40 cursor-not-allowed')}
              onClick={() => canAdvance() && setStep(4)}
              disabled={!canAdvance()}
            >
              <span>التالي</span><ChevronLeft size={16} aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      {/* ══ STEP 4: Skills + Review ════════════════════════════ */}
      {step === 4 && (
        <div className="space-y-5">
          {/* Skills selection */}
          <div className="riwaq-card space-y-4">
            <div>
              <h2 className="text-lg font-bold mb-1" style={{ color: '#F5EFE0' }}>المهارات المطلوبة</h2>
              <p className="text-sm" style={{ color: '#6B7A94' }}>اختر كل المهارات ذات الصلة بمشروعك</p>
            </div>
            <div className="flex flex-wrap gap-2" role="group" aria-label="اختيار المهارات">
              {ALL_SKILLS.map(skill => {
                const active = form.skills.includes(skill);
                return (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => toggleSkill(skill)}
                    className="rounded-full px-4 py-1.5 text-xs font-medium transition-all"
                    style={{
                      background: active ? 'linear-gradient(135deg,#C8A94A,#F0C96A)' : 'rgba(255,255,255,0.05)',
                      color: active ? '#060C18' : '#9BA8BC',
                      border: active ? 'none' : '1px solid rgba(255,255,255,0.08)',
                      fontFamily: 'Tajawal, sans-serif',
                    }}
                    aria-pressed={active}
                  >
                    {skill}
                  </button>
                );
              })}
            </div>
            {form.skills.length > 0 && (
              <p className="text-xs" style={{ color: '#2DD4BF' }}>
                ✓ تم اختيار {form.skills.length} {form.skills.length === 1 ? 'مهارة' : 'مهارات'}
              </p>
            )}
          </div>

          {/* Final review summary */}
          <div
            className="rounded-xl p-5 space-y-4"
            style={{ background: 'rgba(45,212,191,0.04)', border: '1px solid rgba(45,212,191,0.15)' }}
          >
            <h3 className="text-sm font-bold" style={{ color: '#2DD4BF' }}>✦ ملخص المشروع</h3>
            <dl className="grid grid-cols-2 gap-y-3 gap-x-4 text-sm">
              {[
                ['العنوان',     form.title     || '—'],
                ['التصنيف',    form.category  || '—'],
                ['الميزانية',  form.budget ? `${Number(form.budget).toLocaleString('ar')} ر.س` : '—'],
                ['المدة',      form.duration  || '—'],
                ['مستوى الخبرة', EXPERIENCE_LEVELS.find(l => l.value === form.experienceLevel)?.label || '—'],
                ['المهارات',   form.skills.length ? form.skills.join('، ') : '—'],
              ].map(([key, val]) => (
                <div key={key} className={key === 'المهارات' ? 'col-span-2' : ''}>
                  <dt className="text-xs mb-0.5" style={{ color: '#4A5568' }}>{key}</dt>
                  <dd className="text-sm font-medium leading-snug" style={{ color: '#D0C8BC' }}>{val}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="flex justify-between">
            <button className="btn-ghost gap-2" onClick={() => setStep(3)}>
              <ChevronRight size={16} aria-hidden="true" /><span>السابق</span>
            </button>
            <button className="btn-primary gap-2" onClick={handleSubmit}>
              <span>نشر المشروع</span>
              <span aria-hidden="true">✦</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
