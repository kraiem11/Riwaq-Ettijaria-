/**
 * components/dashboard/DashboardContent.tsx
 *
 * Client Component — handles the Client ↔ Freelancer switcher
 * and renders the correct view.
 *
 * Sub-views:
 *  ClientView    — active projects, incoming bids, AI recommendations
 *  FreelancerView — proposals, earnings, profile completion, AI job matches
 */

'use client';

import { useState } from 'react';
import {
  Briefcase, User, Bell, Settings,
  TrendingUp, Clock, CheckCircle2, Star,
  ChevronLeft, Sparkles, BarChart3,
  MessageSquare, Wallet, Zap,
} from 'lucide-react';
import clsx from 'clsx';

/* ══ Types ═══════════════════════════════════════════════════ */
type View = 'client' | 'freelancer';

/* ══ Static mock data ════════════════════════════════════════ */
const CLIENT_PROJECTS = [
  { id: 1, title: 'تطوير متجر إلكتروني متكامل',   bids: 7,  status: 'active',  budget: '٢٬٠٠٠',  age: 'منذ يومين',   matchScore: 92 },
  { id: 2, title: 'تصميم هوية بصرية لشركة ناشئة', bids: 12, status: 'review',  budget: '٨٠٠',    age: 'منذ ٥ أيام',  matchScore: 88 },
  { id: 3, title: 'تطبيق موبايل لخدمة التوصيل',   bids: 3,  status: 'active',  budget: '٥٬٠٠٠',  age: 'منذ يوم',     matchScore: 95 },
  { id: 4, title: 'حملة تسويق رقمي متكاملة',       bids: 9,  status: 'closed',  budget: '١٬٢٠٠',  age: 'منذ ٣ أسابيع', matchScore: 0 },
] as const;

const FREELANCER_PROPOSALS = [
  { id: 1, title: 'موقع شركة عقارية',            client: 'أحمد الشمري',    amount: '١٬٥٠٠', status: 'pending'  },
  { id: 2, title: 'تطبيق إدارة مخزون',           client: 'سارة القحطاني', amount: '٣٬٢٠٠', status: 'accepted' },
  { id: 3, title: 'منصة تعليمية للأطفال',        client: 'محمد العمري',   amount: '٤٬٨٠٠', status: 'pending'  },
  { id: 4, title: 'إعادة تصميم متجر إلكتروني',   client: 'نورة السالم',   amount: '٩٠٠',   status: 'rejected' },
] as const;

/* ══ Badge helper ════════════════════════════════════════════ */
const STATUS_CONFIG: Record<string, { label: string; cls: string }> = {
  active:   { label: 'نشط',            cls: 'badge-teal'  },
  review:   { label: 'قيد المراجعة',   cls: 'badge-gold'  },
  closed:   { label: 'مغلق',           cls: 'badge-ghost' },
  pending:  { label: 'بانتظار الرد',   cls: 'badge-gold'  },
  accepted: { label: 'مقبول',          cls: 'badge-green' },
  rejected: { label: 'مرفوض',          cls: 'badge-red'   },
};

function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] ?? { label: status, cls: 'badge-gold' };
  if (cfg.cls === 'badge-ghost') {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium"
        style={{ background: 'rgba(255,255,255,0.05)', color: '#4A5568', border: '1px solid rgba(255,255,255,0.08)' }}>
        {cfg.label}
      </span>
    );
  }
  if (cfg.cls === 'badge-red') {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium"
        style={{ background: 'rgba(239,68,68,0.1)', color: '#F87171', border: '1px solid rgba(239,68,68,0.2)' }}>
        {cfg.label}
      </span>
    );
  }
  return <span className={`${cfg.cls} text-[11px] px-2 py-0.5`}>{cfg.label}</span>;
}

/* ══ Stat Card ═══════════════════════════════════════════════ */
function StatCard({ icon: Icon, label, value, sub, color }: {
  icon: React.ElementType; label: string; value: string; sub?: string; color: string;
}) {
  return (
    <div
      className="rounded-xl p-4 flex flex-col gap-3"
      style={{ background: 'rgba(200,169,74,0.04)', border: '1px solid rgba(200,169,74,0.1)' }}
    >
      <div className="flex items-center gap-2">
        <Icon size={16} style={{ color }} aria-hidden="true" />
        <span className="text-xs" style={{ color: '#6B7A94' }}>{label}</span>
      </div>
      <p className="text-2xl font-black leading-none" style={{ color }}>{value}</p>
      {sub && <p className="text-xs" style={{ color: '#4A5568' }}>{sub}</p>}
    </div>
  );
}

/* ══ CLIENT VIEW ═════════════════════════════════════════════ */
function ClientView() {
  return (
    <div className="space-y-6">
      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={Briefcase}   label="مشاريع نشطة"  value="٣"    sub="من ٤ مشاريع" color="#C8A94A" />
        <StatCard icon={Bell}        label="عروض واردة"   value="٢٢"   sub="٥ جديدة اليوم" color="#2DD4BF" />
        <StatCard icon={CheckCircle2}label="مكتملة"       value="٨"    sub="هذا الشهر"   color="#4ADE80" />
        <StatCard icon={Star}        label="معدل الرضا"   value="٩٧٪"  sub="من العملاء"  color="#F59E0B" />
      </div>

      {/* Projects list */}
      <section aria-labelledby="client-projects-heading">
        <div className="flex items-center justify-between mb-3">
          <h2 id="client-projects-heading" className="text-base font-bold" style={{ color: '#EEE8DC' }}>
            مشاريعي
          </h2>
          <a href="/post-project" className="btn-primary py-1.5 px-3 text-[13px] gap-1.5">
            + مشروع جديد
          </a>
        </div>

        <div className="space-y-2">
          {CLIENT_PROJECTS.map(p => (
            <div
              key={p.id}
              className="flex items-center justify-between gap-4 rounded-xl p-4"
              style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)' }}
            >
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold truncate" style={{ color: '#EEE8DC' }}>{p.title}</p>
                <p className="text-xs mt-0.5" style={{ color: '#4A5568' }}>{p.age}</p>
              </div>
              <div className="flex items-center gap-3 shrink-0 flex-wrap justify-end">
                <span className="text-xs" style={{ color: '#8C95A8' }}>{p.bids} عرض</span>
                <span className="text-sm font-bold" style={{ color: '#C8A94A' }}>{p.budget} ر.س</span>
                <StatusBadge status={p.status} />
                {p.status === 'active' && (
                  <button className="btn-ghost py-1 px-3 text-xs" aria-label={`مراجعة عروض ${p.title}`}>
                    مراجعة العروض
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* AI Insight box */}
      <div
        className="rounded-xl p-5 flex gap-4 items-start"
        style={{
          background: 'linear-gradient(135deg,rgba(200,169,74,0.07),rgba(45,212,191,0.04))',
          border: '1px solid rgba(200,169,74,0.2)',
        }}
        role="note"
        aria-label="توصية الذكاء الاصطناعي"
      >
        <div
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
          style={{ background: 'rgba(200,169,74,0.12)', border: '1px solid rgba(200,169,74,0.2)' }}
          aria-hidden="true"
        >
          <Sparkles size={18} style={{ color: '#C8A94A' }} />
        </div>
        <div>
          <p className="text-sm font-bold mb-1" style={{ color: '#C8A94A' }}>توصية الذكاء الاصطناعي</p>
          <p className="text-[13px] leading-relaxed" style={{ color: '#8C95A8' }}>
            مشروع &quot;تطوير متجر إلكتروني&quot; تلقّى ٧ عروض، أفضل ٣ منها يتوافقون{' '}
            <strong style={{ color: '#C8A94A' }}>٩٢٪</strong>{' '}
            مع متطلباتك. اضغط لعرض ملفاتهم.
          </p>
          <button className="btn-outline mt-3 py-1.5 px-3 text-[13px] gap-1.5">
            <span>عرض أفضل المرشحين</span>
            <ChevronLeft size={13} aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══ FREELANCER VIEW ═════════════════════════════════════════ */
function FreelancerView() {
  const completionPct = 78;

  return (
    <div className="space-y-6">
      {/* Profile card + completion */}
      <div className="grid sm:grid-cols-2 gap-4">
        {/* Profile */}
        <div className="riwaq-card flex gap-4 items-center">
          <div
            className="h-14 w-14 shrink-0 rounded-full flex items-center justify-center text-xl font-black"
            style={{ background: 'linear-gradient(135deg,#C8A94A,#2DD4BF)', color: '#060C18' }}
            aria-label="صورة الملف الشخصي"
          >
            ع
          </div>
          <div>
            <p className="text-base font-bold" style={{ color: '#EEE8DC' }}>عمر الخالد</p>
            <p className="text-xs mb-2" style={{ color: '#6B7A94' }}>مطوّر Full Stack · الرياض</p>
            <div className="flex gap-2 flex-wrap">
              <span className="badge-gold text-[10px]">موثّق ✓</span>
              <span className="badge-teal text-[10px] flex items-center gap-1"><Star size={9} /> Top Rated</span>
            </div>
          </div>
        </div>

        {/* Profile completion */}
        <div className="riwaq-card">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-medium" style={{ color: '#8C95A8' }}>اكتمال الملف الشخصي</p>
            <span className="text-xl font-black" style={{ color: '#C8A94A' }}>{completionPct}٪</span>
          </div>
          <div className="h-1.5 rounded-full overflow-hidden mb-3" style={{ background: 'rgba(255,255,255,0.08)' }}>
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${completionPct}%`, background: 'linear-gradient(90deg,#C8A94A,#2DD4BF)' }}
              role="progressbar"
              aria-valuenow={completionPct}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="نسبة اكتمال الملف الشخصي"
            />
          </div>
          <p className="text-xs" style={{ color: '#4A5568' }}>
            أضف ٣ نماذج من أعمالك للوصول إلى ١٠٠٪ وزيادة فرص القبول
          </p>
          <button className="btn-ghost mt-3 w-full py-1.5 text-xs">تحديث الملف الشخصي</button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <StatCard icon={Wallet}   label="أرباح الشهر"   value="٢١٠٠"  sub="ريال سعودي"    color="#C8A94A" />
        <StatCard icon={MessageSquare} label="عروض مرسلة" value="٥"   sub="٢ بانتظار الرد" color="#2DD4BF" />
        <StatCard icon={BarChart3} label="نسبة الإتمام" value="٩٤٪"   sub="من المشاريع"   color="#4ADE80" />
      </div>

      {/* Proposals */}
      <section aria-labelledby="proposals-heading">
        <h2 id="proposals-heading" className="text-base font-bold mb-3" style={{ color: '#EEE8DC' }}>
          عروضي الأخيرة
        </h2>
        <div className="space-y-2">
          {FREELANCER_PROPOSALS.map(p => (
            <div
              key={p.id}
              className="flex items-center justify-between gap-4 rounded-xl p-4"
              style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)' }}
            >
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold truncate" style={{ color: '#EEE8DC' }}>{p.title}</p>
                <p className="text-xs mt-0.5" style={{ color: '#4A5568' }}>العميل: {p.client}</p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-sm font-bold" style={{ color: '#C8A94A' }}>{p.amount} ر.س</span>
                <StatusBadge status={p.status} />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* AI job match box */}
      <div
        className="rounded-xl p-5 flex gap-4 items-start"
        style={{ background: 'rgba(45,212,191,0.04)', border: '1px solid rgba(45,212,191,0.15)' }}
        role="note"
        aria-label="توصيات المشاريع من الذكاء الاصطناعي"
      >
        <div
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
          style={{ background: 'rgba(45,212,191,0.1)', border: '1px solid rgba(45,212,191,0.2)' }}
          aria-hidden="true"
        >
          <Zap size={18} style={{ color: '#2DD4BF' }} />
        </div>
        <div>
          <p className="text-sm font-bold mb-1" style={{ color: '#2DD4BF' }}>✦ مشاريع مقترحة لك</p>
          <p className="text-[13px] leading-relaxed" style={{ color: '#8C95A8' }}>
            وجد الذكاء الاصطناعي{' '}
            <strong style={{ color: '#2DD4BF' }}>١٤ مشروعاً</strong>{' '}
            يتطابق ٨٩٪ فأكثر مع مهاراتك في React و Node.js. أعلى مشروع بميزانية ٦٬٥٠٠ ر.س.
          </p>
          <button className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-medium" style={{ color: '#2DD4BF' }}>
            <span>عرض المشاريع المقترحة</span>
            <ChevronLeft size={13} aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══ Main Dashboard Component ════════════════════════════════ */
export default function DashboardContent() {
  const [view, setView] = useState<View>('client');

  return (
    <div className="space-y-6">

      {/* ── Dashboard header ─────────────────────────────────── */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black" style={{ color: '#F5EFE0' }}>
            مرحباً، عمر 👋
          </h1>
          <p className="text-sm mt-1" style={{ color: '#6B7A94' }}>
            آخر تسجيل دخول — اليوم الساعة ١٠:٣٢ ص
          </p>
        </div>

        {/* View Switcher */}
        <div
          className="flex gap-1 rounded-xl p-1"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
          role="tablist"
          aria-label="تبديل عرض لوحة التحكم"
        >
          {([['client', 'صاحب عمل', Briefcase], ['freelancer', 'مستقل', User]] as const).map(([v, label, Icon]) => (
            <button
              key={v}
              role="tab"
              aria-selected={view === v}
              onClick={() => setView(v)}
              className={clsx(
                'flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all duration-200',
                {
                  'text-[#060C18]': view === v,
                  'text-[#8C95A8] hover:text-riwaq-text': view !== v,
                }
              )}
              style={{
                background: view === v ? 'linear-gradient(135deg,#C8A94A,#F0C96A)' : 'transparent',
                fontFamily: 'Tajawal, sans-serif',
              }}
            >
              <Icon size={15} aria-hidden="true" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: 'rgba(200,169,74,0.1)' }} role="separator" />

      {/* ── View panel ───────────────────────────────────────── */}
      <div role="tabpanel" aria-label={view === 'client' ? 'عرض صاحب العمل' : 'عرض المستقل'}>
        {view === 'client'     ? <ClientView />     : <FreelancerView />}
      </div>
    </div>
  );
}
