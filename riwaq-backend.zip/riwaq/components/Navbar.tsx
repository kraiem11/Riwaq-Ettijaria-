/**
 * components/Navbar.tsx
 *
 * Sticky top navigation bar with:
 *  - Riwaq logo + wordmark
 *  - Primary nav links
 *  - "AI-powered" badge
 *  - Auth buttons (login / sign-up)
 *
 * Uses Next.js <Link> for client-side navigation.
 * Active link highlighting via usePathname().
 */

'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Sparkles, Menu, X } from 'lucide-react';
import { useState } from 'react';
import clsx from 'clsx';

/* ── Nav link definitions ─────────────────────────────────── */
const NAV_LINKS = [
  { href: '/',             label: 'الرئيسية'     },
  { href: '/post-project', label: 'نشر مشروع'    },
  { href: '/dashboard',    label: 'لوحة التحكم'  },
  { href: '/explore',      label: 'استكشاف'      },
] as const;

/* ── Component ────────────────────────────────────────────── */
export default function Navbar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header
      className="sticky top-0 z-50 border-b"
      style={{
        background: 'rgba(6,12,24,0.92)',
        backdropFilter: 'blur(14px)',
        borderColor: 'rgba(200,169,74,0.1)',
      }}
    >
      {/* ── Main bar ────────────────────────────────────────── */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-[60px] items-center justify-between gap-4">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div
              className="flex h-8 w-8 items-center justify-center rounded-lg text-base font-black"
              style={{ background: 'linear-gradient(135deg,#C8A94A,#F0C96A)', color: '#060C18' }}
              aria-hidden="true"
            >
              ر
            </div>
            <span className="text-xl font-black tracking-tight" style={{ color: '#F0EDE8' }}>
              رواق
            </span>
          </Link>

          {/* Desktop nav links */}
          <nav className="hidden md:flex items-center gap-1" aria-label="التنقل الرئيسي">
            {NAV_LINKS.map(({ href, label }) => (
              <Link
                key={href}
                href={href}
                className={clsx(
                  'px-3 py-1.5 text-sm rounded-md transition-all duration-200',
                  pathname === href
                    ? 'text-riwaq-text bg-white/[0.06]'
                    : 'text-riwaq-muted hover:text-riwaq-text hover:bg-white/[0.04]'
                )}
              >
                {label}
              </Link>
            ))}
          </nav>

          {/* Right side: badge + auth */}
          <div className="hidden md:flex items-center gap-3 shrink-0">
            {/* AI badge */}
            <span className="badge-teal flex items-center gap-1.5 text-[11px]">
              <Sparkles size={11} aria-hidden="true" />
              مدعوم بالذكاء الاصطناعي
            </span>

            {/* Auth buttons */}
            <Link href="/login" className="btn-outline py-[7px] px-4 text-[13px]">
              تسجيل الدخول
            </Link>
            <Link href="/signup" className="btn-primary py-[7px] px-4 text-[13px]">
              ابدأ مجاناً
            </Link>
          </div>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden btn-ghost p-2"
            onClick={() => setMobileOpen(prev => !prev)}
            aria-label={mobileOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
          >
            {mobileOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* ── Mobile drawer ────────────────────────────────────── */}
      {mobileOpen && (
        <div
          className="md:hidden border-t px-4 py-4 space-y-1"
          style={{ borderColor: 'rgba(200,169,74,0.1)', background: '#0D1525' }}
        >
          {NAV_LINKS.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              onClick={() => setMobileOpen(false)}
              className={clsx(
                'block px-3 py-2 rounded-lg text-sm transition-all',
                pathname === href
                  ? 'text-riwaq-text bg-white/[0.06]'
                  : 'text-riwaq-muted hover:text-riwaq-text'
              )}
            >
              {label}
            </Link>
          ))}
          <div className="pt-3 flex gap-2">
            <Link href="/login"  className="btn-outline flex-1 justify-center text-[13px] py-2">تسجيل الدخول</Link>
            <Link href="/signup" className="btn-primary flex-1 justify-center text-[13px] py-2">ابدأ مجاناً</Link>
          </div>
        </div>
      )}
    </header>
  );
}
