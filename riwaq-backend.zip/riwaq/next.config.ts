import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Enable React strict mode for better dev warnings
  reactStrictMode: true,

  // Image domains allowed
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "cdn.riwaq.sa" },
      { protocol: "https", hostname: "*.r2.cloudflarestorage.com" },
      { protocol: "https", hostname: "avatars.githubusercontent.com" },
    ],
  },

  // Custom headers for security
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-DNS-Prefetch-Control", value: "on" },
          { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
          { key: "X-Content-Type-Options",   value: "nosniff" },
          { key: "X-Frame-Options",          value: "SAMEORIGIN" },
        ],
      },
    ];
  },

  // Rewrites for clean API versioning
  async rewrites() {
    return [
      { source: "/v1/:path*", destination: "/api/:path*" },
    ];
  },
};

export default nextConfig;
