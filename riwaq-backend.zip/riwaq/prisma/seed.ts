// ╔══════════════════════════════════════════════════════════╗
// ║  رواق — Database Seed Script                             ║
// ║  Run: npm run db:seed                                    ║
// ╚══════════════════════════════════════════════════════════╝
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding رواق database...\n");

  // ── Clear existing data ──────────────────────────────────
  await prisma.$transaction([
    prisma.notification.deleteMany(),
    prisma.review.deleteMany(),
    prisma.message.deleteMany(),
    prisma.escrow.deleteMany(),
    prisma.milestone.deleteMany(),
    prisma.contract.deleteMany(),
    prisma.proposal.deleteMany(),
    prisma.project.deleteMany(),
    prisma.wallet.deleteMany(),
    prisma.userSkill.deleteMany(),
    prisma.userLanguage.deleteMany(),
    prisma.user.deleteMany(),
  ]);

  const passwordHash = await bcrypt.hash("Test1234!", 12);

  // ── Create Users ─────────────────────────────────────────
  const client1 = await prisma.user.create({
    data: {
      email: "ahmed@example.com", passwordHash,
      username: "ahmed_client", displayName: "أحمد الشمري",
      role: "CLIENT", status: "ACTIVE", kycLevel: "EMAIL_VERIFIED",
      country: "SA", city: "الرياض",
      wallet: { create: { balanceFils: 500000n } }, // 5000 SAR
    },
  });

  const freelancer1 = await prisma.user.create({
    data: {
      email: "sara@example.com", passwordHash,
      username: "sara_dev", displayName: "سارة الأحمدي",
      role: "FREELANCER", status: "ACTIVE", kycLevel: "ID_VERIFIED",
      country: "SA", city: "جدة", hourlyRate: 38,
      bio: "مصمّمة UI/UX بخبرة 5 سنوات. متخصصة في تصميم منتجات الويب والجوال.",
      tagline: "أحوّل أفكارك إلى تجارب مستخدم رائعة",
      avgRating: 4.9, reviewCount: 96, completedJobs: 104,
      availability: "part_time",
      wallet: { create: { balanceFils: 120000n } },
      skills: {
        create: [
          { skill: "Figma",       level: 5, yearsExp: 5 },
          { skill: "Tailwind CSS",level: 4, yearsExp: 3 },
          { skill: "Framer",      level: 4, yearsExp: 2 },
          { skill: "UI Design",   level: 5, yearsExp: 5 },
          { skill: "UX Research", level: 4, yearsExp: 4 },
        ],
      },
      languages: { create: [{ language: "ar", proficiency: "native" }, { language: "en", proficiency: "fluent" }] },
    },
  });

  const freelancer2 = await prisma.user.create({
    data: {
      email: "khalid@example.com", passwordHash,
      username: "khalid_dev", displayName: "خالد القحطاني",
      role: "FREELANCER", status: "ACTIVE", kycLevel: "FULLY_VERIFIED",
      country: "SA", city: "الرياض", hourlyRate: 45,
      bio: "مطوّر Full-Stack بخبرة 7 سنوات في React, Node.js, وقواعد البيانات.",
      avgRating: 4.8, reviewCount: 211, completedJobs: 224,
      availability: "full_time",
      wallet: { create: { balanceFils: 350000n } },
      skills: {
        create: [
          { skill: "React",       level: 5, yearsExp: 6 },
          { skill: "Node.js",     level: 5, yearsExp: 7 },
          { skill: "TypeScript",  level: 4, yearsExp: 4 },
          { skill: "PostgreSQL",  level: 4, yearsExp: 5 },
          { skill: "Next.js",     level: 5, yearsExp: 4 },
          { skill: "Docker",      level: 3, yearsExp: 3 },
        ],
      },
      languages: { create: [{ language: "ar", proficiency: "native" }, { language: "en", proficiency: "conversational" }] },
    },
  });

  const admin = await prisma.user.create({
    data: {
      email: "admin@riwaq.sa", passwordHash,
      username: "riwaq_admin", displayName: "مدير النظام",
      role: "ADMIN", status: "ACTIVE", kycLevel: "FULLY_VERIFIED",
      country: "SA",
      wallet: { create: {} },
    },
  });

  // ── Create Projects ──────────────────────────────────────
  const project1 = await prisma.project.create({
    data: {
      clientId: client1.id,
      title: "تطوير متجر إلكتروني متكامل لبيع الملابس",
      description: `نبحث عن مطوّر متمرّس لبناء متجر إلكتروني احترافي لبيع الملابس النسائية.

المتطلبات التقنية:
• واجهة أمامية بـ Next.js 14 مع Tailwind CSS
• لوحة تحكم لإدارة المنتجات والطلبات
• تكامل مع بوابة دفع STC Pay و Stripe
• نظام إدارة المخزون
• دعم كامل للغة العربية وRTL
• تصميم متجاوب لجميع الأجهزة

معايير القبول:
• سرعة تحميل أقل من 2 ثانية
• تقييم Lighthouse أعلى من 90
• توثيق شامل للكود`,
      category:        "WEB_DEVELOPMENT",
      skills:          ["React", "Next.js", "Node.js", "PostgreSQL", "Tailwind CSS"],
      budgetType:      "fixed",
      budgetMin:       2000,
      budgetMax:       3500,
      timeline:        "1m",
      experienceLevel: "EXPERT",
      status:          "OPEN",
      publishedAt:     new Date(),
    },
  });

  const project2 = await prisma.project.create({
    data: {
      clientId: client1.id,
      title: "تصميم هوية بصرية كاملة لشركة ناشئة",
      description: `شركتنا الناشئة في مجال التقنية المالية تحتاج هوية بصرية احترافية وعصرية.

المطلوب:
• شعار احترافي بصيغ متعددة
• دليل الهوية البصرية الكامل
• تصميم بطاقات العمل والقرطاسية
• ملف PPT قالب للعروض التقديمية
• أيقونات تطبيق الجوال`,
      category:        "GRAPHIC_DESIGN",
      skills:          ["Figma", "Adobe Illustrator", "Brand Design", "UI Design"],
      budgetType:      "fixed",
      budgetMin:       800,
      budgetMax:       1500,
      timeline:        "2w",
      experienceLevel: "MID",
      status:          "OPEN",
      publishedAt:     new Date(),
    },
  });

  // ── Create Proposals ─────────────────────────────────────
  await prisma.proposal.create({
    data: {
      projectId:    project1.id,
      freelancerId: freelancer2.id,
      coverLetter:  "مرحباً، لديّ خبرة 7 سنوات في بناء متاجر إلكترونية بـ Next.js. أتمكن من تسليم مشروعك في الوقت المحدد مع ضمان أعلى معايير الجودة. لديّ 3 متاجر مشابهة أنجزتها بنجاح.",
      bidAmount:    2800,
      bidType:      "fixed",
      deliveryDays: 28,
      aiMatchScore: 94,
      milestones:   [
        { title: "إعداد البنية التحتية", description: "Next.js, DB, Auth", amount: 800, dueDate: null },
        { title: "واجهة المتجر الأمامية", description: "صفحات المنتجات والسلة", amount: 1200, dueDate: null },
        { title: "لوحة التحكم والتكاملات", description: "Dashboard + STC Pay", amount: 800, dueDate: null },
      ],
    },
  });

  await prisma.proposal.create({
    data: {
      projectId:    project2.id,
      freelancerId: freelancer1.id,
      coverLetter:  "خبرتي في تصميم الهوية البصرية لأكثر من 50 شركة ناشئة تجعلني الخيار الأمثل لمشروعكم. سأقدم 3 مقترحات مختلفة للاختيار.",
      bidAmount:    1200,
      bidType:      "fixed",
      deliveryDays: 14,
      aiMatchScore: 96,
    },
  });

  // ── Update proposal counts ────────────────────────────────
  await prisma.project.update({ where: { id: project1.id }, data: { proposalCount: 1 } });
  await prisma.project.update({ where: { id: project2.id }, data: { proposalCount: 1 } });

  console.log("✅ Seed completed successfully!\n");
  console.log("👤 Test accounts:");
  console.log("   Client:     ahmed@example.com / Test1234!");
  console.log("   Freelancer: khalid@example.com / Test1234!");
  console.log("   Admin:      admin@riwaq.sa / Test1234!");
  console.log("\n📦 Created: 3 users, 2 projects, 2 proposals");
}

main()
  .catch(e => { console.error("❌ Seed failed:", e); process.exit(1); })
  .finally(() => prisma.$disconnect());
