/**
 * app/page.tsx — Home Page (Server Component)
 *
 * Assembles all homepage sections:
 *  1. Navbar
 *  2. HeroSection
 *  3. FeaturesSection
 *  4. Minimal footer
 *
 * Client sub-components handle interactivity (search, hover states).
 */

import Navbar from '@/components/Navbar';
import HeroSection from '@/components/home/HeroSection';
import FeaturesSection from '@/components/home/FeaturesSection';
import { type Metadata } from 'next';

export const metadata: Metadata = {
  title: 'رواق — منصة العمل الحر بالذكاء الاصطناعي',
};

export default function HomePage() {
  return (
    <div className="min-h-screen" style={{ background: '#060C18' }}>
      <Navbar />
      <main>
        <HeroSection />
        <FeaturesSection />

        {/* ── Testimonials placeholder ─────────────────────── */}
        {/*
         * TODO: Add <TestimonialsSection /> here.
         * Component should fetch testimonials from /api/testimonials
         * and display them in a scrolling carousel.
         */}

        {/* ── Pricing placeholder ──────────────────────────── */}
        {/*
         * TODO: Add <PricingSection /> here.
         * Show Free / Pro / Enterprise tiers.
         */}
      </main>

      {/* ── Footer ──────────────────────────────────────────── */}
      <footer
        className="mt-12 border-t py-8 text-center"
        style={{ borderColor: 'rgba(200,169,74,0.1)', background: '#060C18' }}
      >
        <p className="text-xs" style={{ color: '#2E3A50' }}>
          © ٢٠٢٦ رواق — منصة العمل الحر بالذكاء الاصطناعي · جميع الحقوق محفوظة
        </p>
      </footer>
    </div>
  );
}
