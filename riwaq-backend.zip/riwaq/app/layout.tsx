/**
 * app/layout.tsx — Root Layout
 *
 * Sets up:
 *  - Arabic RTL direction on <html>
 *  - Tajawal font via next/font (zero-CLS, self-hosted via Google)
 *  - Global metadata (SEO, Open Graph)
 *  - Viewport theme-color for mobile browsers
 */

import type { Metadata, Viewport } from 'next';
import { Tajawal } from 'next/font/google';
import './globals.css';

/* ── Google Font — Tajawal (Arabic-optimised) ─────────────── */
const tajawal = Tajawal({
  subsets: ['arabic', 'latin'],
  weight: ['300', '400', '500', '700', '800', '900'],
  variable: '--font-tajawal',
  display: 'swap',
});

/* ── Site-wide metadata ────────────────────────────────────── */
export const metadata: Metadata = {
  title: {
    default: 'رواق — منصة العمل الحر بالذكاء الاصطناعي',
    template: '%s | رواق',
  },
  description:
    'رواق تربط أصحاب العمل بأفضل المستقلين العرب، مدعومةً بأدوات الذكاء الاصطناعي لتسريع كل خطوة من خطوات المشروع.',
  keywords: ['عمل حر', 'مستقلين', 'مشاريع', 'ذكاء اصطناعي', 'رواق', 'freelance', 'arabic'],
  authors: [{ name: 'Riwaq Platform' }],
  openGraph: {
    title: 'رواق — منصة العمل الحر بالذكاء الاصطناعي',
    description: 'ابحث عن أفضل المستقلين العرب أو أعلن عن مشروعك في دقائق.',
    locale: 'ar_SA',
    type: 'website',
    siteName: 'رواق',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'رواق — منصة العمل الحر بالذكاء الاصطناعي',
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: '#060C18',
  width: 'device-width',
  initialScale: 1,
};

/* ── Root Layout Component ─────────────────────────────────── */
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    /*
     * dir="rtl" + lang="ar" — crucial for correct Arabic rendering,
     * logical CSS properties, and screen-reader announcements.
     */
    <html lang="ar" dir="rtl" className={tajawal.variable}>
      <body className="font-arabic antialiased bg-riwaq-bg text-riwaq-text">
        {/*
         * TODO: Wrap with providers here when needed:
         *   <QueryClientProvider> for React Query
         *   <SessionProvider>     for NextAuth
         *   <ToastProvider>       for notifications
         */}
        {children}
      </body>
    </html>
  );
}
