/**
 * app/post-project/page.tsx — Post a Project Page
 *
 * Layout:
 *  - Navbar
 *  - Page header with breadcrumb
 *  - Left: MultiStepForm (main)
 *  - Right: Tips sidebar
 */

import type { Metadata } from 'next';
import Navbar from '@/components/Navbar';
import MultiStepForm from '@/components/post-project/MultiStepForm';
import { Lightbulb, ShieldCheck, Zap } from 'lucide-react';

export const metadata: Metadata = {
  title: 'نشر مشروع جديد',
  description: 'انشر مشروعك في دقائق واستقبل عروضاً من أفضل المستقلين العرب.',
};

/* ── Sidebar tips (static) ────────────────────────────────── */
const TIPS = [
  {
    icon: Zap,
    color: '#C8A94A',
    title: 'عنوان واضح = عروض أسرع',
    text: 'المشاريع ذات العناوين الوصفية تحصل على عروض أسرع بنسبة ٤٥٪.',
  },
  {
    icon: Lightbulb,
    color: '#2DD4BF',
    title: 'استخدم الذكاء الاصطناعي',
    text: 'أداة صياغة المشروع تولّد توصيفات احترافية بضغطة زر واحدة.',
  },
  {
    icon: ShieldCheck,
    color: '#8B5CF6',
    title: 'مدفوعاتك محمية',
    text: 'نظام Escrow يحفظ مدفوعاتك حتى تستلم العمل وتوافق عليه.',
  },
] as const;

export default function PostProjectPage() {
  return (
    <div className="min-h-screen" style={{ background: '#060C18' }}>
      <Navbar />

      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">

        {/* Page header */}
        <header className="mb-8">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-xs mb-3" style={{ color: '#4A5568' }} aria-label="مسار التنقل">
            <a href="/" style={{ color: '#4A5568' }} className="hover:text-riwaq-gold transition-colors">الرئيسية</a>
            <span aria-hidden="true">/</span>
            <span style={{ color: '#C8A94A' }}>نشر مشروع</span>
          </nav>
          <h1 className="text-2xl font-black" style={{ color: '#F5EFE0' }}>
            نشر مشروع جديد
          </h1>
          <p className="mt-1 text-sm" style={{ color: '#8C95A8' }}>
            أجب على الأسئلة التالية — أو اضغط &quot;صياغة بالذكاء الاصطناعي&quot; في الخطوة الثانية لتوليد توصيف كامل
          </p>
        </header>

        {/* Content: form + sidebar */}
        <div className="grid gap-8 lg:grid-cols-[1fr_300px]">

          {/* ── Main form ───────────────────────────────────── */}
          <MultiStepForm />

          {/* ── Tips sidebar ────────────────────────────────── */}
          <aside className="space-y-4" aria-label="نصائح لنشر المشروع">
            {TIPS.map(({ icon: Icon, color, title, text }) => (
              <div
                key={title}
                className="rounded-xl p-4 flex gap-3"
                style={{ background: '#0D1525', border: '1px solid rgba(200,169,74,0.1)' }}
              >
                <div
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg mt-0.5"
                  style={{ background: `${color}15`, border: `1px solid ${color}30` }}
                  aria-hidden="true"
                >
                  <Icon size={17} style={{ color }} />
                </div>
                <div>
                  <p className="text-sm font-bold mb-1" style={{ color: '#EEE8DC' }}>{title}</p>
                  <p className="text-xs leading-relaxed" style={{ color: '#6B7A94' }}>{text}</p>
                </div>
              </div>
            ))}

            {/* Escrow badge */}
            <div
              className="rounded-xl p-4 text-center"
              style={{
                background: 'linear-gradient(135deg, rgba(200,169,74,0.06), rgba(45,212,191,0.04))',
                border: '1px solid rgba(200,169,74,0.15)',
              }}
            >
              <p className="text-3xl mb-2" aria-hidden="true">🔒</p>
              <p className="text-sm font-bold" style={{ color: '#C8A94A' }}>مدفوعاتك في أمان تام</p>
              <p className="text-xs mt-1 leading-relaxed" style={{ color: '#6B7A94' }}>
                نظام Escrow المُشفَّر يحمي أموالك حتى تُوافق على التسليم النهائي
              </p>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}
