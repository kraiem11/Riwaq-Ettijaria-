/**
 * app/api/ai/generate-description/route.ts
 *
 * POST /api/ai/generate-description
 *
 * Accepts:  { title: string; category: string; additionalContext?: string }
 * Returns:  streaming text — the AI-generated Arabic project description
 *
 * Uses Anthropic claude-sonnet-4-20250514 via the official SDK.
 * Streamed response allows the client to display text incrementally.
 */

import Anthropic from '@anthropic-ai/sdk';
import { NextRequest } from 'next/server';

/* ── Anthropic client (server-only, key from env) ─────────── */
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!, // set in .env.local
});

/* ── System prompt ─────────────────────────────────────────── */
const SYSTEM_PROMPT = `
أنت خبير متخصص في كتابة توصيفات مشاريع العمل الحر باللغة العربية الفصحى.
مهمتك كتابة توصيف مشروع احترافي وشامل ومقنع يجذب المستقلين المتميزين.

يجب أن يتضمن التوصيف الأقسام التالية بشكل واضح:
١. نبذة عن المشروع (فقرة تمهيدية)
٢. المهام والمسؤوليات المطلوبة
٣. المخرجات والتسليمات المتوقعة
٤. المتطلبات والمهارات الأساسية

القواعد:
- اكتب باللغة العربية الفصحى فقط
- أسلوب مهني ومحترم
- طول مناسب: ٣-٥ فقرات
- لا تتضمن أي نص خارج التوصيف (لا مقدمات، لا تحيات)
`.trim();

/* ── POST handler ──────────────────────────────────────────── */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, category, additionalContext } = body as {
      title: string;
      category: string;
      additionalContext?: string;
    };

    /* Basic input validation */
    if (!title?.trim() || !category?.trim()) {
      return new Response(
        JSON.stringify({ error: 'يرجى توفير عنوان المشروع والتصنيف' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    /* Build the user message */
    const userMessage = [
      `عنوان المشروع: ${title.trim()}`,
      `التصنيف: ${category.trim()}`,
      additionalContext?.trim()
        ? `سياق إضافي: ${additionalContext.trim()}`
        : null,
      '\nاكتب التوصيف الاحترافي للمشروع:',
    ]
      .filter(Boolean)
      .join('\n');

    /* Create streaming request to Anthropic */
    const stream = anthropic.messages.stream({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 800,
      system: SYSTEM_PROMPT,
      messages: [{ role: 'user', content: userMessage }],
    });

    /* Pipe the stream to a ReadableStream for Next.js response */
    const readable = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of stream) {
            if (
              chunk.type === 'content_block_delta' &&
              chunk.delta.type === 'text_delta'
            ) {
              controller.enqueue(new TextEncoder().encode(chunk.delta.text));
            }
          }
        } finally {
          controller.close();
        }
      },
    });

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Transfer-Encoding': 'chunked',
      },
    });

  } catch (error) {
    console.error('[/api/ai/generate-description]', error);
    return new Response(
      JSON.stringify({ error: 'حدث خطأ أثناء معالجة الطلب. يرجى المحاولة مجدداً.' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
