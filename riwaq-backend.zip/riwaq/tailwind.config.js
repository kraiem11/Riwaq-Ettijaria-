/** @type {import('tailwindcss').Config} */
module.exports = {
  // Scan all app/component files for class usage
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      // ── Brand color palette ──────────────────────────────────────
      colors: {
        riwaq: {
          bg:        '#060C18', // deep navy page background
          surface:   '#0D1525', // card surfaces
          border:    '#1A2540', // default borders
          gold:      '#C8A94A', // primary brand gold
          'gold-lt': '#F0C96A', // lighter gold for gradients
          teal:      '#2DD4BF', // AI/interactive accent
          text:      '#F0EDE8', // primary text
          muted:     '#8C95A8', // muted/secondary text
          faint:     '#4A5568', // hint/placeholder text
        },
      },
      // ── Typography ─────────────────────────────────────────────
      fontFamily: {
        arabic: ['Tajawal', 'Cairo', 'sans-serif'],
      },
      // ── Geometric background pattern ────────────────────────────
      backgroundImage: {
        'geo-grid': `repeating-linear-gradient(0deg,transparent,transparent 40px,rgba(200,169,74,.06) 40px,rgba(200,169,74,.06) 41px),
                     repeating-linear-gradient(90deg,transparent,transparent 40px,rgba(200,169,74,.06) 40px,rgba(200,169,74,.06) 41px)`,
      },
      // ── Animation keyframes ─────────────────────────────────────
      keyframes: {
        'fade-up': {
          '0%':   { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'glow-pulse': {
          '0%,100%': { opacity: '0.6' },
          '50%':     { opacity: '1' },
        },
        'blink': {
          '0%,100%': { opacity: '1' },
          '50%':     { opacity: '0' },
        },
      },
      animation: {
        'fade-up':    'fade-up 0.5s ease-out forwards',
        'glow-pulse': 'glow-pulse 2.5s ease-in-out infinite',
        'blink':      'blink 0.7s infinite',
      },
    },
  },
  plugins: [],
};
